
import React, { useState, useMemo } from 'react';
import { Sidebar } from './components/Sidebar';
import { StatCard } from './components/StatCard';
import { RequestList } from './components/RequestList';
import { IntakeForm } from './components/IntakeForm';
import { RequestDetail } from './components/RequestDetail';
import { AIChat } from './components/AIChat';
import { VendorList } from './components/VendorList';
import { VendorDetail } from './components/VendorDetail';
import { VendorFormModal } from './components/VendorFormModal';
import { PolicyGuideModal } from './components/PolicyGuideModal';
import { ApprovalQueue } from './components/ApprovalQueue';
import { PurchaseOrderList } from './components/PurchaseOrderList';
import { Sourcing } from './components/Sourcing';
import { Invoices } from './components/Invoices';
import { ContractList } from './components/ContractList';
import { ContractDetail } from './components/ContractDetail';
import { Insights } from './components/Insights';
import { Integrations } from './components/Integrations';

import { 
  Banknote, 
  Clock, 
  FileCheck, 
  AlertOctagon,
  Bell,
  Search,
  Plus
} from 'lucide-react';
import { ProcurementRequest, RequestStatus, Priority, Vendor, PurchaseOrder, SourcingProject, Invoice, Contract, ContractExtractionResponse } from './types';

// Initial Mock Data
const INITIAL_REQUESTS: ProcurementRequest[] = [
  {
    id: 'REQ-1042',
    title: 'Salesforce Enterprise Renewal',
    requester: 'Alice Chen',
    department: 'Sales',
    category: 'Software',
    amount: 45000,
    currency: 'USD',
    vendorName: 'Salesforce.com',
    description: 'Annual renewal for 50 enterprise licenses. Critical for sales ops.',
    businessJustification: 'Essential CRM for revenue tracking.',
    status: RequestStatus.PENDING_APPROVAL,
    priority: Priority.HIGH,
    createdAt: '2023-10-25T10:00:00Z',
    attachments: ['OrderForm_2024.pdf'],
    comments: [
        { id: 'c1', author: 'Alice Chen', text: 'Uploaded the latest order form.', timestamp: '2023-10-25T10:05:00Z', role: 'Requester' },
        { id: 'c2', author: 'System', text: 'Risk Analysis complete. Score: 20/100.', timestamp: '2023-10-25T10:06:00Z', role: 'AI Bot' }
    ],
    approvalSteps: [
        { id: 's1', name: 'Manager Approval', role: 'Manager', status: 'approved', approverName: 'Bob Director', timestamp: '2023-10-25T14:00:00Z' },
        { id: 's2', name: 'IT Security Review', role: 'IT', status: 'approved', approverName: 'Sec Team', timestamp: '2023-10-26T09:00:00Z' },
        { id: 's3', name: 'Finance Approval', role: 'Finance', status: 'current' },
        { id: 's4', name: 'VP Approval', role: 'VP', status: 'pending' }
    ],
    aiAnalysis: {
      riskScore: 20,
      riskFactors: [],
      summary: "Standard enterprise renewal.",
      recommendedCategory: "Software",
      policyCheck: true,
      complianceNotes: "Passes auto-check.",
      suggestedChannel: 'Contract' as any,
      impactedDocuments: ["MSA Addendum"]
    }
  },
  {
    id: 'REQ-1043',
    title: 'New High-Performance Laptops',
    requester: 'Bob Smith',
    department: 'Engineering',
    category: 'Hardware',
    amount: 12000,
    currency: 'USD',
    vendorName: 'Apple',
    description: 'Refresh for new engineering hires.',
    businessJustification: 'Hiring plan Q4.',
    status: RequestStatus.APPROVED,
    priority: Priority.MEDIUM,
    createdAt: '2023-10-26T14:30:00Z',
    attachments: [],
    comments: [],
    approvalSteps: [
        { id: 's1', name: 'Manager Approval', role: 'Manager', status: 'approved', approverName: 'Sarah VP', timestamp: '2023-10-26T15:00:00Z' },
        { id: 's2', name: 'Finance Approval', role: 'Finance', status: 'approved', approverName: 'Finance Team', timestamp: '2023-10-27T10:00:00Z' }
    ],
    purchaseOrderNumber: 'PO-9001',
    aiAnalysis: {
      riskScore: 10,
      riskFactors: [],
      summary: "Hardware purchase from preferred vendor.",
      recommendedCategory: "Hardware",
      policyCheck: true,
      complianceNotes: "Standard IT equipment.",
      suggestedChannel: 'Catalog' as any,
      impactedDocuments: ["PO"]
    }
  }
];

const INITIAL_CONTRACTS: Contract[] = [
  {
    id: 'CON-2021',
    title: 'Master Services Agreement',
    vendorName: 'Salesforce.com',
    type: 'MSA',
    value: 500000,
    startDate: '2023-01-01',
    endDate: '2025-12-31',
    status: 'Active',
    paymentTerms: 'Net 30',
    autoRenewal: true,
    owner: 'Sarah Legal'
  },
  {
    id: 'CON-2022',
    title: 'Software License Agreement',
    vendorName: 'Slack',
    type: 'Subscription',
    value: 120000,
    startDate: '2023-06-01',
    endDate: '2024-05-31',
    status: 'Renewal Due',
    paymentTerms: 'Net 45',
    autoRenewal: false,
    owner: 'IT Procurement'
  }
];

const INITIAL_SOURCING: SourcingProject[] = [
  {
    id: 'SRC-3001',
    title: 'Cloud Infrastructure RFP',
    status: 'Active',
    owner: 'Jim Cloud',
    budget: 1200000,
    dueDate: '2024-03-15',
    vendors: ['AWS', 'Azure', 'GCP'],
    type: 'RFP'
  },
  {
    id: 'SRC-3002',
    title: 'Janitorial Services Renewal',
    status: 'Selection',
    owner: 'Facilities Team',
    budget: 50000,
    dueDate: '2024-02-10',
    vendors: ['CleanCo', 'Shiny Offices'],
    type: 'Renewal'
  }
];

const INITIAL_POS: PurchaseOrder[] = [
  {
    poNumber: 'PO-9001',
    requestId: 'REQ-1043',
    vendorName: 'Apple',
    amount: 12000,
    currency: 'USD',
    status: 'Acknowledged',
    createdAt: '2023-10-27T11:00:00Z',
    description: '10x MacBook Pro Engineering Spec'
  }
];

const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'INV-4001',
    invoiceNumber: 'INV-12345',
    vendorName: 'Apple',
    amount: 12000,
    date: '2023-11-05',
    status: 'Pending Approval',
    matchStatus: 'Matched',
    poNumber: 'PO-9001'
  }
];

const INITIAL_VENDORS: Vendor[] = [
  {
    id: 'V-101',
    name: 'Salesforce.com',
    category: 'Software',
    trustScore: 94,
    isPreferred: true,
    contactName: 'Marc Benioff',
    contactEmail: 'enterprise@salesforce.com',
    website: 'www.salesforce.com',
    description: 'Global leader in CRM and cloud computing solutions.',
    spendLast12M: 450000,
    performanceRating: 4.8,
    onboardingStatus: 'Complete',
    contracts: [INITIAL_CONTRACTS[0]]
  },
  {
    id: 'V-102',
    name: 'Apple',
    category: 'Hardware',
    trustScore: 99,
    isPreferred: true,
    contactName: 'IT Sales',
    contactEmail: 'it-sales@apple.com',
    website: 'apple.com',
    description: 'Computing hardware and software.',
    spendLast12M: 125000,
    performanceRating: 5.0,
    onboardingStatus: 'Complete',
    contracts: []
  }
];

const App: React.FC = () => {
  const [view, setView] = useState('dashboard'); 
  const [requests, setRequests] = useState<ProcurementRequest[]>(INITIAL_REQUESTS);
  const [contracts, setContracts] = useState<Contract[]>(INITIAL_CONTRACTS);
  const [sourcingProjects, setSourcingProjects] = useState<SourcingProject[]>(INITIAL_SOURCING);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(INITIAL_POS);
  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES);
  const [vendors, setVendors] = useState<Vendor[]>(INITIAL_VENDORS);

  const [selectedRequest, setSelectedRequest] = useState<ProcurementRequest | null>(null);
  const [selectedContract, setSelectedContract] = useState<Contract | null>(null);
  const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);
  
  const [isVendorModalOpen, setIsVendorModalOpen] = useState(false);
  const [isPolicyModalOpen, setIsPolicyModalOpen] = useState(false);

  const handleNavigate = (target: string) => {
    setView(target);
    if (target !== 'detail') setSelectedRequest(null);
    if (target !== 'contract-detail') setSelectedContract(null);
    if (target !== 'vendor-detail') setSelectedVendor(null);
  };

  const handleRequestSubmit = (req: ProcurementRequest) => {
    setRequests([req, ...requests]);
    setView('dashboard');
  };

  const handleSelectRequest = (req: ProcurementRequest) => {
    setSelectedRequest(req);
    setView('detail');
  };

  const handleSelectContract = (contract: Contract) => {
    setSelectedContract(contract);
    setView('contract-detail');
  };

  const handleSelectVendor = (vendor: Vendor) => {
    setSelectedVendor(vendor);
    setView('vendor-detail');
  };

  const handleStatusChange = (id: string, status: RequestStatus) => {
    setRequests(requests.map(r => r.id === id ? { ...r, status } : r));
    if (selectedRequest?.id === id) setSelectedRequest({ ...selectedRequest, status });
    
    // Auto-generate PO if approved
    if (status === RequestStatus.APPROVED) {
        const req = requests.find(r => r.id === id);
        if (req && !req.purchaseOrderNumber) {
            handleCreatePO(req);
        }
    }
  };

  const handleCreatePO = (r: ProcurementRequest) => {
    const poNumber = `PO-${Math.floor(Math.random() * 9000) + 1000}`;
    const newPO: PurchaseOrder = {
        poNumber,
        requestId: r.id,
        vendorName: r.vendorName,
        amount: r.amount,
        currency: r.currency,
        status: 'Sent',
        createdAt: new Date().toISOString(),
        description: r.description
    };
    setPurchaseOrders([newPO, ...purchaseOrders]);
    setRequests(requests.map(req => req.id === r.id ? { ...req, purchaseOrderNumber: poNumber, status: RequestStatus.ORDER_PLACED } : req));
  };

  const handleAddContract = (data: ContractExtractionResponse) => {
      const newContract: Contract = {
          id: `CON-${Math.floor(Math.random() * 9000) + 1000}`,
          title: data.title,
          vendorName: data.vendorName,
          type: data.type,
          value: data.value,
          startDate: data.startDate,
          endDate: data.endDate,
          status: 'Draft',
          paymentTerms: data.paymentTerms,
          autoRenewal: data.autoRenewal,
          owner: 'Alex Comptroller'
      };
      setContracts([newContract, ...contracts]);
  };

  const handleAddSourcing = (title: string, budget: number) => {
      const newProject: SourcingProject = {
          id: `SRC-${Math.floor(Math.random() * 9000) + 1000}`,
          title,
          status: 'Draft',
          owner: 'Alex Comptroller',
          budget,
          dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          vendors: [],
          type: 'RFP'
      };
      setSourcingProjects([newProject, ...sourcingProjects]);
  };

  const handleAddInvoice = (inv: Partial<Invoice>) => {
      const newInvoice: Invoice = {
          id: `INV-${Math.floor(Math.random() * 9000) + 1000}`,
          invoiceNumber: inv.invoiceNumber || 'INV-PENDING',
          vendorName: inv.vendorName || 'Unknown',
          amount: inv.amount || 0,
          date: new Date().toISOString().split('T')[0],
          status: 'Processing',
          matchStatus: 'Pending',
          poNumber: inv.poNumber
      };
      setInvoices([newInvoice, ...invoices]);
  };

  const handleUpdateVendor = (updatedVendor: Vendor) => {
      setVendors(vendors.map(v => v.id === updatedVendor.id ? updatedVendor : v));
      if (selectedVendor?.id === updatedVendor.id) setSelectedVendor(updatedVendor);
  };

  const handleAddVendor = (vendorData: Partial<Vendor>) => {
      const newVendor: Vendor = {
          id: `V-${Math.floor(Math.random() * 900) + 100}`,
          name: vendorData.name || 'New Vendor',
          category: vendorData.category || 'Uncategorized',
          trustScore: vendorData.trustScore || 70,
          isPreferred: vendorData.isPreferred || false,
          contactName: vendorData.contactName || '',
          contactEmail: vendorData.contactEmail || '',
          website: vendorData.website || '',
          description: vendorData.description || '',
          spendLast12M: 0,
          performanceRating: 0,
          onboardingStatus: 'Pending',
          contracts: []
      };
      setVendors([...vendors, newVendor]);
  };

  const handleDeleteVendor = (id: string) => {
      if (window.confirm("Are you sure you want to remove this vendor?")) {
          setVendors(vendors.filter(v => v.id !== id));
          if (selectedVendor?.id === id) setView('vendors');
      }
  };

  const pendingApprovals = requests.filter(r => r.status === RequestStatus.PENDING_APPROVAL);

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900 overflow-hidden">
      <Sidebar 
        activeView={view} 
        onNavigate={handleNavigate} 
        pendingApprovalCount={pendingApprovals.length}
      />
      
      <main className="flex-1 overflow-y-auto h-full relative">
        {/* Global Nav Header */}
        <div className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-6">
            <h2 className="text-xl font-black capitalize text-slate-900 tracking-tight">
              {view === 'detail' ? 'Request Details' : 
               view === 'contract-detail' ? 'Contract Details' : 
               view === 'vendor-detail' ? 'Vendor Profile' :
               view.replace('-', ' ')}
            </h2>
            {view === 'dashboard' && (
                <div className="relative group">
                    <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
                    <input 
                        type="text" 
                        placeholder="Search across orchestration..." 
                        className="pl-10 pr-4 py-2 bg-slate-100 border-transparent border focus:border-indigo-600 focus:bg-white rounded-xl text-sm w-80 outline-none transition-all"
                    />
                </div>
            )}
          </div>
          <div className="flex items-center gap-6">
            <button className="p-2 text-slate-400 hover:text-indigo-600 transition-colors relative">
               <Bell className="w-6 h-6" />
               <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="flex items-center gap-3 bg-slate-100 px-4 py-2 rounded-2xl border border-slate-200">
                <div className="text-right">
                    <div className="text-xs font-black text-slate-900 leading-none">Alex Comptroller</div>
                    <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-1">Finance Admin</div>
                </div>
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black text-sm shadow-lg shadow-indigo-100">
                  AC
                </div>
            </div>
          </div>
        </div>

        <div className="p-8">
          {view === 'dashboard' && (
            <div className="space-y-10 max-w-7xl mx-auto animate-in fade-in duration-500">
              {/* Concierge Entry (Zip Style) */}
              <div className="bg-gradient-to-br from-indigo-600 to-indigo-900 rounded-[2.5rem] p-12 text-white shadow-2xl shadow-indigo-200 flex items-center justify-between relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl group-hover:bg-white/20 transition-all duration-1000"></div>
                 <div className="relative z-10 max-w-xl">
                    <h1 className="text-4xl font-black mb-4 leading-tight tracking-tight">Need to buy something?</h1>
                    <p className="text-indigo-100 text-lg mb-8 opacity-90">Our AI concierge determines the best path for your request—from catalog to complex SOWs.</p>
                    <div className="flex gap-4">
                        <button 
                            onClick={() => setView('intake')}
                            className="bg-white text-indigo-900 px-8 py-4 rounded-2xl font-black shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3"
                        >
                            <Plus className="w-5 h-5" /> Start Request
                        </button>
                        <button 
                            onClick={() => setIsPolicyModalOpen(true)}
                            className="bg-white/10 border border-white/20 backdrop-blur-md px-8 py-4 rounded-2xl font-black hover:bg-white/20 transition-all"
                        >
                            View Buying Policies
                        </button>
                    </div>
                 </div>
                 <div className="relative z-10 hidden lg:block">
                    <div className="w-48 h-48 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-3xl animate-pulse">
                        <Banknote className="w-20 h-20 text-white/80" />
                    </div>
                 </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard 
                  label="In-Flight Spend" 
                  value={`$${requests.filter(r => r.status === RequestStatus.PENDING_APPROVAL).reduce((a,b) => a + b.amount, 0).toLocaleString()}`} 
                  icon={Banknote} 
                  color="indigo"
                  trend="8%"
                  trendUp={true}
                />
                <StatCard 
                  label="Pending My Action" 
                  value={pendingApprovals.length} 
                  icon={Clock} 
                  color="amber" 
                />
                <StatCard 
                  label="Approved MTD" 
                  value={requests.filter(r => r.status === RequestStatus.APPROVED).length} 
                  icon={FileCheck} 
                  color="green" 
                />
                <StatCard 
                  label="Savings Identified" 
                  value="$124k" 
                  icon={AlertOctagon} 
                  color="indigo" 
                />
              </div>

              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black text-slate-900 tracking-tight">Active Intake Pipeline</h3>
                <div className="flex gap-2">
                    <button className="px-4 py-2 text-sm font-bold text-slate-500 hover:text-indigo-600 transition-colors">Filters</button>
                    <button className="px-4 py-2 text-sm font-bold text-slate-500 hover:text-indigo-600 transition-colors">Export</button>
                </div>
              </div>

              <RequestList requests={requests} onSelect={handleSelectRequest} />
            </div>
          )}

          {view === 'intake' && (
            <IntakeForm 
              onSubmit={handleRequestSubmit} 
              onCancel={() => setView('dashboard')} 
            />
          )}

          {view === 'detail' && selectedRequest && (
            <div className="absolute inset-0 z-50 bg-slate-50 animate-in slide-in-from-right-8 duration-300">
               <RequestDetail 
                  request={selectedRequest} 
                  onBack={() => setView('dashboard')}
                  onStatusChange={handleStatusChange}
                  onCreatePO={handleCreatePO}
                  purchaseOrder={purchaseOrders.find(po => po.requestId === selectedRequest.id)}
               />
            </div>
          )}

          {view === 'contracts' && (
             <ContractList 
               contracts={contracts} 
               onSelect={handleSelectContract}
               onAddContract={handleAddContract}
             />
          )}

          {view === 'contract-detail' && selectedContract && (
            <div className="absolute inset-0 z-50 bg-slate-50 animate-in slide-in-from-right-8 duration-300">
              <ContractDetail 
                contract={selectedContract} 
                onBack={() => setView('contracts')}
                allRequests={requests}
                onSelectRequest={handleSelectRequest}
              />
            </div>
          )}

          {view === 'sourcing' && (
            <Sourcing projects={sourcingProjects} onAddProject={handleAddSourcing} />
          )}

          {view === 'purchase-orders' && (
            <PurchaseOrderList purchaseOrders={purchaseOrders} />
          )}

          {view === 'invoices' && (
            <Invoices invoices={invoices} onAddInvoice={handleAddInvoice} />
          )}

          {view === 'approvals' && (
              <ApprovalQueue 
                requests={pendingApprovals}
                onApprove={(id) => handleStatusChange(id, RequestStatus.APPROVED)}
                onReject={(id) => handleStatusChange(id, RequestStatus.REJECTED)}
                onView={handleSelectRequest}
              />
          )}

          {view === 'vendors' && (
             <VendorList 
                vendors={vendors} 
                onSelect={handleSelectVendor} 
                onAdd={() => setIsVendorModalOpen(true)}
                onDelete={handleDeleteVendor}
             />
          )}

          {view === 'vendor-detail' && selectedVendor && (
              <div className="absolute inset-0 z-50 bg-slate-50 animate-in slide-in-from-right-8 duration-300 overflow-y-auto">
                  <div className="p-8">
                      <VendorDetail 
                          vendor={selectedVendor} 
                          onBack={() => setView('vendors')}
                          allRequests={requests}
                          onSelectRequest={handleSelectRequest}
                          onUpdateVendor={handleUpdateVendor}
                          onDelete={() => handleDeleteVendor(selectedVendor.id)}
                      />
                  </div>
              </div>
          )}

          {view === 'insights' && (
            <Insights requests={requests} purchaseOrders={purchaseOrders} invoices={invoices} />
          )}

          {view === 'integrations' && (
            <Integrations integrations={[
              { id: 'int-1', name: 'NetSuite', type: 'ERP', status: 'Connected', lastSync: '10m ago' },
              { id: 'int-2', name: 'Slack', type: 'Collaboration', status: 'Connected', lastSync: '2m ago' },
              { id: 'int-3', name: 'Workday', type: 'HRIS', status: 'Disconnected' },
              { id: 'int-4', name: 'DocuSign', type: 'Legal', status: 'Connected', lastSync: '1h ago' }
            ]} />
          )}

          {/* Fallback for other views */}
          {!['dashboard', 'intake', 'detail', 'approvals', 'vendors', 'vendor-detail', 'contracts', 'contract-detail', 'sourcing', 'purchase-orders', 'invoices', 'insights', 'integrations'].includes(view) && (
            <div className="flex flex-col items-center justify-center py-40 bg-white rounded-3xl border-2 border-dashed border-slate-200">
               <FileCheck className="w-16 h-16 text-slate-200 mb-4" />
               <h3 className="text-xl font-bold text-slate-400 uppercase tracking-widest">{view.replace('-', ' ')} view is coming soon</h3>
            </div>
          )}
        </div>
      </main>

      <VendorFormModal 
          isOpen={isVendorModalOpen} 
          onClose={() => setIsVendorModalOpen(false)} 
          onSubmit={handleAddVendor} 
      />

      <PolicyGuideModal
        isOpen={isPolicyModalOpen}
        onClose={() => setIsPolicyModalOpen(false)}
      />

      <AIChat />
    </div>
  );
};

export default App;
