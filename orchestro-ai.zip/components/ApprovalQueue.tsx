
import React from 'react';
import { ProcurementRequest, RequestStatus } from '../types';
import { CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';

interface ApprovalQueueProps {
  requests: ProcurementRequest[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  onView: (request: ProcurementRequest) => void;
}

export const ApprovalQueue: React.FC<ApprovalQueueProps> = ({ requests, onApprove, onReject, onView }) => {
  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-2">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">My Approvals</h2>
        <p className="text-slate-500">Requests awaiting your review and decision.</p>
      </div>

      {requests.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border border-slate-200 shadow-sm">
          <div className="w-16 h-16 bg-green-50 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-medium text-slate-900">All caught up!</h3>
          <p className="text-slate-500">You have no pending approvals at this time.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {requests.map((req) => (
            <div key={req.id} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex items-center justify-between">
              <div className="flex gap-4 items-start" onClick={() => onView(req)}>
                 <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
                    <Clock className="w-6 h-6" />
                 </div>
                 <div>
                    <div className="flex items-center gap-2">
                       <h3 className="font-bold text-slate-800 hover:text-indigo-600 cursor-pointer">{req.title}</h3>
                       <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">{req.id}</span>
                    </div>
                    <p className="text-sm text-slate-500 mt-1">
                        Requested by <span className="font-medium text-slate-800">{req.requester}</span> for <span className="font-medium text-slate-800">{req.vendorName}</span>
                    </p>
                    <div className="flex gap-3 mt-2 text-xs font-medium text-slate-500">
                        <span className="flex items-center gap-1">
                            Amount: <span className="text-slate-800">${req.amount.toLocaleString()}</span>
                        </span>
                        <span>•</span>
                        <span>{req.department}</span>
                    </div>
                 </div>
              </div>
              
              <div className="flex items-center gap-3">
                 {req.aiAnalysis && req.aiAnalysis.riskScore > 70 && (
                     <div className="flex items-center gap-1 text-amber-600 bg-amber-50 px-3 py-1.5 rounded-lg text-xs font-medium mr-2">
                        <AlertTriangle className="w-3 h-3" /> High Risk
                     </div>
                 )}
                 <button 
                    onClick={() => onReject(req.id)}
                    className="px-4 py-2 text-sm font-medium text-red-600 bg-white border border-red-200 rounded-lg hover:bg-red-50 transition-colors"
                 >
                    Reject
                 </button>
                 <button 
                    onClick={() => onApprove(req.id)}
                    className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 shadow-sm shadow-indigo-200 transition-colors"
                 >
                    Approve
                 </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
