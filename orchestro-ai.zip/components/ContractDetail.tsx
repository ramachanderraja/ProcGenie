
import React, { useState, useRef } from 'react';
import { Contract, ContractAnalysis, ProcurementRequest } from '../types';
import { GeminiService } from '../services/gemini';
import { 
  ArrowLeft, 
  Calendar, 
  DollarSign, 
  FileText, 
  AlertTriangle, 
  Download,
  Sparkles,
  Loader2,
  CheckCircle,
  Clock,
  RefreshCw,
  Scale,
  ShieldAlert,
  Lock,
  UploadCloud,
  X
} from 'lucide-react';

interface ContractDetailProps {
  contract: Contract;
  onBack: () => void;
  allRequests: ProcurementRequest[];
  onSelectRequest: (req: ProcurementRequest) => void;
}

export const ContractDetail: React.FC<ContractDetailProps> = ({ contract, onBack, allRequests, onSelectRequest }) => {
  const [analysis, setAnalysis] = useState<ContractAnalysis | null>(contract.aiAnalysis || null);
  const [analyzing, setAnalyzing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{ name: string; data: string; mimeType: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const relatedRequest = contract.relatedRequestId ? allRequests.find(r => r.id === contract.relatedRequestId) : null;

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
        if (file.type !== 'application/pdf' && !file.type.startsWith('image/')) {
            alert('Please upload a PDF or Image file.');
            return;
        }

        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = reader.result as string;
            // Remove data url prefix (e.g. "data:application/pdf;base64,")
            const base64Data = base64String.split(',')[1];
            
            setUploadedFile({
                name: file.name,
                data: base64Data,
                mimeType: file.type
            });
            setAnalysis(null); // Reset analysis when new file is uploaded
        };
        reader.readAsDataURL(file);
    }
  };

  const handleRemoveFile = () => {
      setUploadedFile(null);
      setAnalysis(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleAnalyze = async () => {
      setAnalyzing(true);
      
      try {
          let result;
          if (uploadedFile) {
              // Analyze uploaded file
              result = await GeminiService.analyzeContract({
                  data: uploadedFile.data,
                  mimeType: uploadedFile.mimeType
              });
          } else {
              // Fallback to mock text analysis if no file
               const mockText = `
                  MASTER SERVICES AGREEMENT
                  
                  Party A: ${contract.vendorName}
                  Party B: Orchestro Inc.
                  Effective Date: ${contract.startDate}
                  End Date: ${contract.endDate}
                  Total Contract Value: $${contract.value}
                  
                  1. PAYMENT TERMS.
                  Payment shall be made ${contract.paymentTerms} from receipt of invoice. Late payments subject to 1.5% interest.
                  
                  2. TERM AND TERMINATION.
                  This agreement ${contract.autoRenewal ? 'automatically renews for successive 1 year terms' : 'expires on the End Date'} unless provided written notice.
                  Termination for Convenience: Orchestro may terminate with 60 days prior written notice. 
                  Termination for Cause: Immediate upon material breach.
                  
                  3. LIABILITY.
                  Limitation of Liability: Vendor's liability shall not exceed 2x the total fees paid in the preceding 12 months.
                  
                  4. INDEMNIFICATION.
                  Vendor agrees to indemnify Customer against all claims, damages, and losses arising from IP infringement. This indemnity is uncapped.
                  
                  5. CONFIDENTIALITY.
                  Confidential information shall be protected for a period of 3 years after termination of this agreement.
                  
                  6. GOVERNING LAW.
                  This agreement is governed by the laws of the State of New York.
                  
                  7. DATA SECURITY.
                  Vendor shall maintain SOC2 Type II compliance. Data breach must be reported within 24 hours.
                  `;
              result = await GeminiService.analyzeContract(mockText);
          }
          setAnalysis(result);
      } catch (e) {
          console.error(e);
          alert("Analysis failed. Please check your API key or try a smaller file.");
      } finally {
          setAnalyzing(false);
      }
  };

  const getRiskBadge = (level: string) => {
    switch(level) {
        case 'High': return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800 border border-red-200"><AlertTriangle className="w-3 h-3 mr-1"/> High Risk</span>;
        case 'Medium': return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200"><AlertTriangle className="w-3 h-3 mr-1"/> Medium Risk</span>;
        case 'Low': return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800 border border-green-200"><CheckCircle className="w-3 h-3 mr-1"/> Low Risk</span>;
        default: return <span className="text-xs text-slate-500">{level}</span>;
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-50">
       {/* Hidden File Input for Logic */}
       <input 
            type="file" 
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".pdf,image/*"
            className="hidden"
        />

       {/* Header */}
       <div className="bg-white border-b border-slate-200 px-8 py-4 flex justify-between items-center sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-slate-800 flex items-center gap-3">
              {contract.title}
              <span className="px-2 py-1 rounded-md text-xs font-medium bg-slate-100 text-slate-600 border border-slate-200">
                {contract.id}
              </span>
            </h1>
            <p className="text-sm text-slate-500">
              {contract.type} with <span className="font-medium text-slate-700">{contract.vendorName}</span>
            </p>
          </div>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 bg-white border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50 transition-colors flex items-center gap-2"
            >
                <UploadCloud className="w-4 h-4" /> Upload PDF
            </button>
            <button 
                onClick={() => alert(`Downloading original contract: ${contract.title}.pdf`)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium border border-transparent transition-colors flex items-center gap-2"
            >
                <Download className="w-4 h-4" /> Download Original
            </button>
        </div>
      </div>

      <div className="flex-1 p-8 overflow-hidden flex gap-6">
          {/* Left: File Upload / Document Preview */}
          <div className="w-1/2 flex flex-col">
             <div className="flex-1 bg-slate-200 rounded-xl border border-slate-300 flex flex-col items-center justify-center relative overflow-hidden group transition-all">
                 {uploadedFile ? (
                    <div className="absolute inset-0 bg-slate-100 flex flex-col items-center justify-center p-8">
                        <div className="w-16 h-16 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                            <FileText className="w-8 h-8 text-red-600" />
                        </div>
                        <h3 className="font-bold text-slate-800 text-lg text-center break-all">{uploadedFile.name}</h3>
                        <p className="text-slate-500 text-sm mt-1">Ready for analysis</p>
                        
                        <button 
                            onClick={handleRemoveFile}
                            className="mt-6 px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-medium text-slate-600 hover:text-red-600 hover:border-red-200 transition-colors flex items-center gap-2"
                        >
                            <X className="w-4 h-4" /> Remove File
                        </button>
                    </div>
                 ) : (
                     <div 
                        className="absolute inset-0 flex flex-col items-center justify-center bg-slate-100 hover:bg-slate-50 transition-colors cursor-pointer" 
                        onClick={() => fileInputRef.current?.click()}
                     >
                        <div className="p-4 bg-white rounded-full shadow-sm mb-4">
                            <UploadCloud className="w-8 h-8 text-indigo-600" />
                        </div>
                        <p className="text-slate-800 font-medium">Upload Contract PDF</p>
                        <p className="text-slate-400 text-sm mt-1">Click or drag file to analyze with AI</p>
                    </div>
                 )}
             </div>
          </div>

          {/* Right: Metadata & AI */}
          <div className="w-1/2 overflow-y-auto space-y-6 pr-2">
              {/* AI Analysis Section */}
              <div className="bg-white rounded-xl shadow-sm border border-indigo-100 overflow-hidden">
                  <div className="bg-gradient-to-r from-indigo-50 to-white px-6 py-3 border-b border-indigo-100 flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-indigo-600" />
                        <h3 className="font-semibold text-indigo-900">Gemini Contract Analysis</h3>
                      </div>
                      <button 
                        onClick={handleAnalyze}
                        disabled={analyzing}
                        className="text-xs bg-indigo-600 text-white px-3 py-1.5 rounded-lg hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-1.5"
                      >
                          {analyzing ? <Loader2 className="w-3 h-3 animate-spin"/> : analysis ? <RefreshCw className="w-3 h-3"/> : <Sparkles className="w-3 h-3"/>}
                          {analyzing ? 'Analyzing...' : analysis ? 'Re-analyze' : 'Analyze Contract'}
                      </button>
                  </div>
                  
                  <div className="p-6">
                      {analyzing ? (
                          <div className="text-center py-8 text-slate-500 flex flex-col items-center">
                              <Loader2 className="w-8 h-8 animate-spin text-indigo-600 mb-3" />
                              <p className="font-medium text-slate-700">Scanning document...</p>
                              <p className="text-xs text-slate-400 mt-1">Extracting key terms and identifying risks</p>
                          </div>
                      ) : analysis ? (
                          <div className="space-y-5 animate-in fade-in duration-300">
                              <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100">
                                  <span className="text-xs font-bold text-indigo-500 uppercase tracking-wide block mb-1.5">Executive Summary</span>
                                  <p className="text-sm text-indigo-900 leading-relaxed">
                                      {analysis.summary}
                                  </p>
                              </div>

                              <div>
                                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Key Terms & Risks</p>
                                  <div className="space-y-3">
                                      {analysis.keyTerms.map((item, idx) => (
                                          <div 
                                            key={idx} 
                                            className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                                                item.riskLevel === 'High' 
                                                ? 'bg-red-50 border-red-200 hover:bg-red-100' 
                                                : 'bg-slate-50 border-slate-100 hover:bg-slate-100'
                                            }`}
                                          >
                                              <div className="flex items-center gap-2">
                                                  {item.riskLevel === 'High' && (
                                                      <AlertTriangle className="w-4 h-4 text-red-600" />
                                                  )}
                                                  <span className={`text-sm font-medium ${
                                                      item.riskLevel === 'High' ? 'text-red-900' : 'text-slate-700'
                                                  }`}>
                                                      {item.term}
                                                  </span>
                                              </div>
                                              <div className="flex items-center gap-3">
                                                  <span className={`text-sm font-semibold ${
                                                      item.riskLevel === 'High' ? 'text-red-900' : 'text-slate-900'
                                                  }`}>
                                                      {item.value}
                                                  </span>
                                                  {getRiskBadge(item.riskLevel)}
                                              </div>
                                          </div>
                                      ))}
                                  </div>
                              </div>

                              {/* Clause Deep Dive */}
                              <div className="pt-4 border-t border-slate-100 space-y-3">
                                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Clause Deep Dive</p>
                                  
                                  <div className="grid grid-cols-1 gap-3">
                                      {/* Indemnification */}
                                      <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 hover:bg-slate-100 transition-colors group">
                                          <div className="flex items-center gap-2 mb-1.5 text-slate-500 group-hover:text-slate-700">
                                              <ShieldAlert className="w-4 h-4" />
                                              <span className="text-xs font-bold uppercase">Indemnification</span>
                                          </div>
                                          <p className="text-sm text-slate-700">{analysis.indemnificationClause || 'Not detected'}</p>
                                      </div>

                                      {/* Confidentiality */}
                                      <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 hover:bg-slate-100 transition-colors group">
                                           <div className="flex items-center gap-2 mb-1.5 text-slate-500 group-hover:text-slate-700">
                                              <Lock className="w-4 h-4" />
                                              <span className="text-xs font-bold uppercase">Confidentiality</span>
                                          </div>
                                          <p className="text-sm text-slate-700">{analysis.confidentialityClause || 'Not detected'}</p>
                                      </div>

                                      {/* Governing Law */}
                                      <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 hover:bg-slate-100 transition-colors group">
                                           <div className="flex items-center gap-2 mb-1.5 text-slate-500 group-hover:text-slate-700">
                                              <Scale className="w-4 h-4" />
                                              <span className="text-xs font-bold uppercase">Governing Law</span>
                                          </div>
                                          <p className="text-sm text-slate-700">{analysis.governingLaw || 'Not detected'}</p>
                                      </div>
                                  </div>
                              </div>

                              <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-100">
                                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                                      <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Termination Clause</p>
                                      <p className="text-sm text-slate-700">{analysis.terminationClause}</p>
                                  </div>
                                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                                      <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Renewal Date</p>
                                      <p className="text-sm text-slate-700 font-medium flex items-center gap-1.5">
                                          <Clock className="w-4 h-4 text-indigo-500"/> 
                                          {analysis.renewalDate || contract.endDate}
                                      </p>
                                  </div>
                              </div>
                          </div>
                      ) : (
                          <div className="text-center py-8 flex flex-col items-center">
                              <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center mb-3 text-indigo-600">
                                  <Sparkles className="w-6 h-6" />
                              </div>
                              <p className="text-sm font-medium text-slate-700">Unlock AI Insights</p>
                              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                                  Upload a contract PDF to automatically extract payment terms, renewal dates, and identify high-risk clauses.
                              </p>
                          </div>
                      )}
                  </div>
              </div>

              {/* Metadata Card */}
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-6">
                  <h3 className="font-bold text-slate-800">Contract Details</h3>
                  
                  <div className="grid grid-cols-2 gap-6">
                      <div>
                          <p className="text-xs text-slate-500 uppercase mb-1">Status</p>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              contract.status === 'Active' ? 'bg-green-100 text-green-800' : 
                              contract.status === 'Renewal Due' ? 'bg-amber-100 text-amber-800' : 
                              'bg-slate-100 text-slate-800'
                          }`}>
                              {contract.status}
                          </span>
                      </div>
                       <div>
                          <p className="text-xs text-slate-500 uppercase mb-1">Auto-Renewal</p>
                          <div className="flex items-center gap-2">
                             {contract.autoRenewal ? <CheckCircle className="w-4 h-4 text-green-600"/> : <Clock className="w-4 h-4 text-slate-400"/>}
                             <span className="text-sm font-medium text-slate-800">{contract.autoRenewal ? 'Enabled' : 'Disabled'}</span>
                          </div>
                      </div>
                      <div>
                          <p className="text-xs text-slate-500 uppercase mb-1">Total Value</p>
                          <div className="flex items-center gap-1 text-slate-900 font-bold">
                              <DollarSign className="w-4 h-4 text-slate-400" />
                              {contract.value.toLocaleString()}
                          </div>
                      </div>
                       <div>
                          <p className="text-xs text-slate-500 uppercase mb-1">Payment Terms</p>
                          <span className="text-sm font-medium text-slate-800">{contract.paymentTerms}</span>
                      </div>
                      <div>
                          <p className="text-xs text-slate-500 uppercase mb-1">Effective Date</p>
                          <div className="flex items-center gap-1 text-sm text-slate-700">
                              <Calendar className="w-4 h-4 text-slate-400" />
                              {contract.startDate}
                          </div>
                      </div>
                      <div>
                          <p className="text-xs text-slate-500 uppercase mb-1">Expiration Date</p>
                          <div className="flex items-center gap-1 text-sm text-slate-700">
                              <Calendar className="w-4 h-4 text-slate-400" />
                              {contract.endDate}
                          </div>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 uppercase mb-1">Related Request</p>
                        {relatedRequest ? (
                            <button 
                                onClick={() => onSelectRequest(relatedRequest)}
                                className="flex items-center gap-2 text-sm font-medium text-indigo-600 hover:text-indigo-800 transition-colors group"
                            >
                                <FileText className="w-4 h-4" />
                                <span className="group-hover:underline">{relatedRequest.title} ({relatedRequest.id})</span>
                            </button>
                        ) : (
                            <span className="text-sm text-slate-400">None linked</span>
                        )}
                     </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100">
                      <p className="text-xs text-slate-500 uppercase mb-2">Owner</p>
                      <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-xs font-bold">
                              {contract.owner.substring(0,2).toUpperCase()}
                          </div>
                          <span className="text-sm font-medium text-slate-800">{contract.owner}</span>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};
