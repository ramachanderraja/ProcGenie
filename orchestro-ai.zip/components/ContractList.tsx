
import React, { useState, useRef } from 'react';
import { Contract, ContractExtractionResponse } from '../types';
import { GeminiService } from '../services/gemini';
import { Search, Filter, Plus, FileText, AlertTriangle, CheckCircle, Clock, ArrowUpRight, Loader2, UploadCloud } from 'lucide-react';

interface ContractListProps {
  contracts: Contract[];
  onSelect: (contract: Contract) => void;
  onAddContract?: (data: ContractExtractionResponse) => void;
}

export const ContractList: React.FC<ContractListProps> = ({ contracts, onSelect, onAddContract }) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredContracts = contracts.filter(c => {
      const matchesSearch = c.title.toLowerCase().includes(search.toLowerCase()) || c.vendorName.toLowerCase().includes(search.toLowerCase());
      const matchesFilter = filter === 'All' || c.status === filter;
      return matchesSearch && matchesFilter;
  });

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (!file) return;
      
      if (file.type !== 'application/pdf' && !file.type.startsWith('image/')) {
          alert('Please upload a PDF or Image file.');
          return;
      }

      setIsUploading(true);
      try {
          const reader = new FileReader();
          reader.onloadend = async () => {
              const base64String = reader.result as string;
              const base64Data = base64String.split(',')[1];
              
              const result = await GeminiService.extractContractData({
                  data: base64Data,
                  mimeType: file.type
              });
              
              if (onAddContract) {
                  onAddContract(result);
              }
              setIsUploading(false);
              // Reset input
              if (fileInputRef.current) fileInputRef.current.value = '';
          };
          reader.readAsDataURL(file);
      } catch (error) {
          console.error(error);
          alert('Failed to analyze contract. Please try again.');
          setIsUploading(false);
      }
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
        case 'Active': return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 border border-green-200"><CheckCircle className="w-3 h-3 mr-1"/> Active</span>;
        case 'Renewal Due': return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200"><AlertTriangle className="w-3 h-3 mr-1"/> Renewal Due</span>;
        case 'Expired': return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600 border border-slate-200">Expired</span>;
        case 'Draft': return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-600 border border-blue-100">Draft</span>;
        default: return null;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 relative">
      {isUploading && (
          <div className="absolute inset-0 z-50 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center rounded-xl">
              <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mb-4" />
              <h3 className="text-lg font-bold text-slate-800">Analyzing Contract...</h3>
              <p className="text-slate-500">Extracting metadata and identifying risks with Gemini</p>
          </div>
      )}

      <input 
        type="file" 
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept=".pdf,image/*"
        className="hidden"
      />

      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Contract Repository</h2>
          <p className="text-slate-500">Centralized management for all MSAs, SOWs, and NDAs.</p>
        </div>
        <button 
            onClick={() => fileInputRef.current?.click()}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 shadow-sm flex items-center gap-2 transition-all active:scale-95"
        >
          <UploadCloud className="w-4 h-4" /> Upload Contract
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <p className="text-xs font-medium text-slate-500 uppercase">Total Value</p>
              <p className="text-2xl font-bold text-slate-900 mt-1">${contracts.reduce((acc,c) => acc + c.value, 0).toLocaleString()}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <p className="text-xs font-medium text-slate-500 uppercase">Active Contracts</p>
              <p className="text-2xl font-bold text-green-600 mt-1">{contracts.filter(c => c.status === 'Active').length}</p>
          </div>
           <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <p className="text-xs font-medium text-slate-500 uppercase">Renewal Due (30d)</p>
              <p className="text-2xl font-bold text-amber-600 mt-1">{contracts.filter(c => c.status === 'Renewal Due').length}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <p className="text-xs font-medium text-slate-500 uppercase">Avg. Term</p>
              <p className="text-2xl font-bold text-indigo-600 mt-1">12.5 Mos</p>
          </div>
      </div>

      {/* Filters & Search */}
      <div className="flex gap-4 items-center bg-white p-2 rounded-xl border border-slate-200 shadow-sm">
         <div className="relative flex-1">
             <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
             <input 
                type="text" 
                placeholder="Search by title, vendor or ID..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-transparent rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-colors" 
             />
         </div>
         <div className="h-8 w-[1px] bg-slate-200"></div>
         <div className="flex gap-2">
             {['All', 'Active', 'Renewal Due', 'Expired'].map(s => (
                 <button 
                    key={s}
                    onClick={() => setFilter(s)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${filter === s ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
                 >
                    {s}
                 </button>
             ))}
         </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 font-medium">
            <tr>
              <th className="px-6 py-3">Contract Title</th>
              <th className="px-6 py-3">Vendor</th>
              <th className="px-6 py-3">Type</th>
              <th className="px-6 py-3">Value</th>
              <th className="px-6 py-3">Effective Date</th>
              <th className="px-6 py-3">End Date</th>
              <th className="px-6 py-3">Status</th>
              <th className="px-6 py-3 text-right"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredContracts.map(contract => (
                <tr key={contract.id} onClick={() => onSelect(contract)} className="hover:bg-slate-50 transition-colors cursor-pointer group">
                    <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                             <div className="p-2 bg-slate-100 rounded-lg text-slate-500">
                                <FileText className="w-4 h-4" />
                             </div>
                             <div>
                                 <p className="font-medium text-slate-900">{contract.title}</p>
                                 <p className="text-xs text-slate-500">{contract.id}</p>
                             </div>
                        </div>
                    </td>
                    <td className="px-6 py-4 font-medium text-slate-700">{contract.vendorName}</td>
                    <td className="px-6 py-4">
                         <span className="inline-block px-2 py-1 bg-slate-100 text-slate-600 rounded text-xs font-medium border border-slate-200">
                             {contract.type}
                         </span>
                    </td>
                    <td className="px-6 py-4 font-mono text-slate-600">${contract.value.toLocaleString()}</td>
                    <td className="px-6 py-4 text-slate-600">{contract.startDate}</td>
                    <td className="px-6 py-4 text-slate-600">{contract.endDate}</td>
                    <td className="px-6 py-4">{getStatusBadge(contract.status)}</td>
                    <td className="px-6 py-4 text-right">
                        <ArrowUpRight className="w-4 h-4 text-slate-300 group-hover:text-indigo-600 transition-colors" />
                    </td>
                </tr>
            ))}
             {filteredContracts.length === 0 && (
                  <tr>
                      <td colSpan={8} className="text-center py-12 text-slate-500">
                          No contracts found matching your search.
                      </td>
                  </tr>
              )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
