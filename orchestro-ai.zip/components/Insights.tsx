
import React, { useMemo } from 'react';
import { ArrowUpRight, ArrowDownRight, PieChart, BarChart3, Download, Banknote, Clock, FileCheck, ShieldCheck } from 'lucide-react';
import { ProcurementRequest, PurchaseOrder, Invoice } from '../types';

interface InsightsProps {
  requests: ProcurementRequest[];
  purchaseOrders: PurchaseOrder[];
  invoices: Invoice[];
}

export const Insights: React.FC<InsightsProps> = ({ requests, purchaseOrders, invoices }) => {
  const totalSpend = useMemo(() => {
    return requests.reduce((acc, r) => acc + r.amount, 0);
  }, [requests]);

  const categoryData = useMemo(() => {
    const counts: Record<string, number> = {};
    requests.forEach(r => {
      counts[r.category] = (counts[r.category] || 0) + r.amount;
    });
    return Object.entries(counts).map(([label, amt]) => ({
      label,
      amt: `$${(amt / 1000).toFixed(1)}k`,
      val: (amt / totalSpend) * 100,
      color: label === 'Software' ? 'bg-indigo-500' : label === 'Hardware' ? 'bg-cyan-500' : 'bg-teal-500'
    }));
  }, [requests, totalSpend]);

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-2 duration-500 max-w-7xl mx-auto">
        <div className="flex justify-between items-end">
            <div>
                <h1 className="text-4xl font-black text-slate-900 tracking-tight">Spend Insights</h1>
                <p className="text-slate-500 text-lg mt-2">Real-time analytics on company spending and operational efficiency.</p>
            </div>
            <div className="flex gap-4">
                 <div className="bg-white border border-slate-200 p-1 rounded-2xl flex shadow-sm">
                    <button className="px-4 py-2 text-sm font-bold text-indigo-600 bg-indigo-50 rounded-xl">Last 30 Days</button>
                    <button className="px-4 py-2 text-sm font-bold text-slate-500 hover:text-slate-700">MTD</button>
                    <button className="px-4 py-2 text-sm font-bold text-slate-500 hover:text-slate-700">YTD</button>
                </div>
                <button 
                    onClick={() => alert("Downloading report as CSV...")}
                    className="bg-slate-900 text-white px-6 py-2 rounded-xl font-bold hover:bg-slate-800 transition-all active:scale-95 flex items-center gap-2"
                >
                    <Download className="w-5 h-5" /> Export
                </button>
            </div>
        </div>

        {/* Top Line Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
             <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm relative overflow-hidden group">
                <div className="absolute -right-4 -top-4 w-24 h-24 bg-indigo-50 rounded-full group-hover:scale-110 transition-transform duration-500"></div>
                <p className="text-xs font-black text-slate-400 uppercase tracking-widest relative z-10">Total Pipeline Value</p>
                <div className="flex items-baseline gap-2 mt-4 relative z-10">
                    <h3 className="text-4xl font-black text-slate-900">${(totalSpend / 1000).toFixed(1)}k</h3>
                    <span className="text-xs font-black text-green-600 flex items-center bg-green-50 px-2 py-1 rounded-lg"><ArrowUpRight className="w-3 h-3"/> 12%</span>
                </div>
             </div>
              <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm relative overflow-hidden group">
                <div className="absolute -right-4 -top-4 w-24 h-24 bg-amber-50 rounded-full group-hover:scale-110 transition-transform duration-500"></div>
                <p className="text-xs font-black text-slate-400 uppercase tracking-widest relative z-10">Avg. Cycle Time</p>
                <div className="flex items-baseline gap-2 mt-4 relative z-10">
                    <h3 className="text-4xl font-black text-slate-900">1.4d</h3>
                    <span className="text-xs font-black text-green-600 flex items-center bg-green-50 px-2 py-1 rounded-lg"><ArrowDownRight className="w-3 h-3"/> 0.2d</span>
                </div>
             </div>
              <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm relative overflow-hidden group">
                <div className="absolute -right-4 -top-4 w-24 h-24 bg-emerald-50 rounded-full group-hover:scale-110 transition-transform duration-500"></div>
                <p className="text-xs font-black text-slate-400 uppercase tracking-widest relative z-10">Match Rate</p>
                <div className="flex items-baseline gap-2 mt-4 relative z-10">
                    <h3 className="text-4xl font-black text-slate-900">92%</h3>
                    <span className="text-xs font-black text-slate-400 flex items-center bg-slate-50 px-2 py-1 rounded-lg">Target: 95%</span>
                </div>
             </div>
              <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm relative overflow-hidden group">
                <div className="absolute -right-4 -top-4 w-24 h-24 bg-indigo-50 rounded-full group-hover:scale-110 transition-transform duration-500"></div>
                <p className="text-xs font-black text-slate-400 uppercase tracking-widest relative z-10">AI Confidence</p>
                <div className="flex items-baseline gap-2 mt-4 relative z-10">
                    <h3 className="text-4xl font-black text-slate-900">98.4%</h3>
                    <span className="text-xs font-black text-indigo-600 flex items-center bg-indigo-50 px-2 py-1 rounded-lg"><ShieldCheck className="w-3 h-3"/> Robust</span>
                </div>
             </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Spend by Category */}
            <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-10">
                    <h3 className="text-xl font-black text-slate-900 flex items-center gap-3"><PieChart className="w-6 h-6 text-indigo-600"/> Spend by Category</h3>
                </div>
                <div className="space-y-8">
                    {categoryData.map(item => (
                        <div key={item.label} className="group">
                            <div className="flex justify-between text-sm mb-3">
                                <span className="text-slate-600 font-bold group-hover:text-slate-900 transition-colors">{item.label}</span>
                                <span className="text-slate-900 font-black">{item.amt}</span>
                            </div>
                            <div className="h-3 bg-slate-50 rounded-full overflow-hidden">
                                <div className={`h-full ${item.color} rounded-full transition-all duration-1000 ease-out`} style={{ width: `${item.val}%` }}></div>
                            </div>
                        </div>
                    ))}
                    {categoryData.length === 0 && <div className="text-center py-20 text-slate-400 font-bold">No categorical data available.</div>}
                </div>
            </div>

             {/* Spend by Department (Mocked Trends) */}
            <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm">
                 <div className="flex items-center justify-between mb-10">
                    <h3 className="text-xl font-black text-slate-900 flex items-center gap-3"><BarChart3 className="w-6 h-6 text-indigo-600"/> Velocity Trends</h3>
                </div>
                <div className="flex items-end justify-between h-56 pt-8 px-4">
                    {[
                        { label: 'Jan', val: 40 },
                        { label: 'Feb', val: 55 },
                        { label: 'Mar', val: 35 },
                        { label: 'Apr', val: 70 },
                        { label: 'May', val: 65 },
                        { label: 'Jun', val: 85 },
                    ].map(item => (
                        <div key={item.label} className="flex flex-col items-center gap-4 group w-1/8 flex-1">
                             <div className="w-full bg-slate-50 rounded-2xl relative h-full flex items-end group-hover:bg-indigo-50 transition-all duration-500 p-1">
                                <div className="w-full bg-indigo-600 rounded-xl transition-all duration-1000 ease-out shadow-lg shadow-indigo-100 group-hover:bg-indigo-700" style={{ height: `${item.val}%` }}></div>
                             </div>
                             <span className="text-xs font-black text-slate-400 group-hover:text-slate-900 transition-colors">{item.label}</span>
                        </div>
                    ))}
                </div>
                <div className="mt-8 pt-8 border-t border-slate-50 flex items-center justify-between">
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Efficiency Forecast</p>
                    <p className="text-sm font-black text-indigo-600">+15.4% Expected Improvement</p>
                </div>
            </div>
        </div>
    </div>
  );
};
