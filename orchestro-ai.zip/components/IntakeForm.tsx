
import React, { useState, useRef } from 'react';
import { ProcurementRequest, RequestStatus, Priority, BuyingChannel, CatalogItem } from '../types';
import { GeminiService } from '../services/gemini';
import { Sparkles, ArrowRight, Loader2, X, Search, ShoppingBag, FileText, Zap, ShieldCheck, CreditCard } from 'lucide-react';

interface IntakeFormProps {
  onSubmit: (request: ProcurementRequest) => void;
  onCancel: () => void;
}

const MOCK_CATALOG: CatalogItem[] = [
  { id: 'cat-1', name: 'MacBook Pro M3 Max', description: '14-inch, 36GB Unified Memory', price: 3499, currency: 'USD', vendorName: 'Apple', category: 'Hardware', imageUrl: '', deliveryTime: '2-3 days' },
  { id: 'cat-2', name: 'Dell UltraSharp 27 Monitor', description: '4K USB-C Hub Monitor', price: 599, currency: 'USD', vendorName: 'Dell', category: 'Hardware', imageUrl: '', deliveryTime: '5 days' },
  { id: 'cat-3', name: 'Herman Miller Aeron', description: 'Size B, Graphite, Adjustable arms', price: 1200, currency: 'USD', vendorName: 'Herman Miller', category: 'Facilities', imageUrl: '', deliveryTime: '2 weeks' }
];

export const IntakeForm: React.FC<IntakeFormProps> = ({ onSubmit, onCancel }) => {
  const [step, setStep] = useState<'prompt' | 'catalog' | 'review'>('prompt');
  const [prompt, setPrompt] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<Partial<ProcurementRequest> | null>(null);
  const [selectedCatalogItem, setSelectedCatalogItem] = useState<CatalogItem | null>(null);

  const handleIntake = async () => {
    if (!prompt.trim()) return;
    setIsAnalyzing(true);
    try {
      const result = await GeminiService.analyzeIntakePrompt(prompt);
      setAnalysisResult(result);
      
      if (result.aiAnalysis?.suggestedChannel === BuyingChannel.CATALOG) {
        setStep('catalog');
      } else {
        setStep('review');
      }
    } catch (e) {
      alert("AI Analysis failed. Switching to manual mode.");
      setStep('review');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFinalSubmit = () => {
    const baseRequest: Partial<ProcurementRequest> = {
      ...analysisResult,
      id: `REQ-${Math.floor(Math.random() * 9000) + 1000}`,
      requester: 'Current User',
      status: RequestStatus.PENDING_APPROVAL,
      createdAt: new Date().toISOString(),
      comments: [],
      approvalSteps: [
        { id: 's1', name: 'Manager Approval', role: 'Manager', status: 'current', approverName: 'Sarah Manager' },
        { id: 's2', name: 'Finance Review', role: 'Finance', status: 'pending' }
      ]
    };

    if (selectedCatalogItem) {
      baseRequest.amount = selectedCatalogItem.price;
      baseRequest.vendorName = selectedCatalogItem.vendorName;
      baseRequest.title = `Purchase: ${selectedCatalogItem.name}`;
      baseRequest.buyingChannel = BuyingChannel.CATALOG;
    }

    onSubmit(baseRequest as ProcurementRequest);
  };

  return (
    <div className="max-w-4xl mx-auto py-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight mb-3">What can we help you buy today?</h1>
        <p className="text-slate-500 text-lg">Our AI-powered concierge will find the right channel and handle the paperwork.</p>
      </div>

      {step === 'prompt' && (
        <div className="bg-white p-8 rounded-3xl shadow-2xl shadow-indigo-100 border border-slate-200">
          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., I need a new high-performance laptop for my engineering work, around $3500."
              className="w-full h-40 p-6 text-xl text-slate-800 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-indigo-500 focus:ring-0 outline-none transition-all resize-none placeholder-slate-400"
            />
            <div className="absolute bottom-4 right-4 flex items-center gap-4">
              <button
                onClick={handleIntake}
                disabled={isAnalyzing || !prompt.trim()}
                className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-50 shadow-xl shadow-indigo-200 transition-all active:scale-95"
              >
                {isAnalyzing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5 fill-current" />}
                {isAnalyzing ? "Determining path..." : "Submit Request"}
              </button>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-3 gap-4">
            <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-100">
              <ShoppingBag className="w-6 h-6 text-indigo-600 mb-2" />
              <h4 className="font-bold text-indigo-900 text-sm">Catalog Buying</h4>
              <p className="text-xs text-indigo-700">Pre-approved items with one-click ordering.</p>
            </div>
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100">
              <FileText className="w-6 h-6 text-emerald-600 mb-2" />
              <h4 className="font-bold text-emerald-900 text-sm">Contract Services</h4>
              <p className="text-xs text-emerald-700">Renewals and SOWs from approved vendors.</p>
            </div>
            <div className="p-4 bg-amber-50 rounded-xl border border-amber-100">
              <Zap className="w-6 h-6 text-amber-600 mb-2" />
              <h4 className="font-bold text-amber-900 text-sm">Quick Quotes</h4>
              <p className="text-xs text-amber-700">Competative bids for non-standard items.</p>
            </div>
          </div>
        </div>
      )}

      {step === 'catalog' && (
        <div className="space-y-6">
          <div className="bg-indigo-600 p-6 rounded-2xl text-white flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold flex items-center gap-2"><Sparkles className="w-5 h-5" /> AI Suggestion</h2>
              <p className="text-indigo-100 text-sm">We found matching items in our internal catalog.</p>
            </div>
            <button onClick={() => setStep('review')} className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm font-medium">Skip to manual</button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MOCK_CATALOG.map(item => (
              <div 
                key={item.id}
                onClick={() => {
                  setSelectedCatalogItem(item);
                  setStep('review');
                }}
                className="bg-white p-6 rounded-2xl border-2 border-slate-100 hover:border-indigo-500 cursor-pointer transition-all flex justify-between group shadow-sm"
              >
                <div>
                  <h3 className="font-bold text-slate-900 group-hover:text-indigo-600">{item.name}</h3>
                  <p className="text-sm text-slate-500 mt-1">{item.description}</p>
                  <div className="flex gap-4 mt-4 text-xs font-medium text-slate-600">
                    <span className="flex items-center gap-1"><CreditCard className="w-3 h-3" /> {item.vendorName}</span>
                    <span className="flex items-center gap-1"><Zap className="w-3 h-3" /> {item.deliveryTime} delivery</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-slate-900">${item.price}</div>
                  <div className="text-xs text-slate-500 uppercase mt-1">{item.currency}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {step === 'review' && (
        <div className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden">
          <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Review Your Request</h2>
              <p className="text-slate-500">Confirm the details automatically extracted by AI.</p>
            </div>
            <div className="px-4 py-1.5 bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-wider">
              {analysisResult?.aiAnalysis?.suggestedChannel || "Standard Request"}
            </div>
          </div>

          <div className="p-8 space-y-8">
            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Request Title</label>
                  <input 
                    type="text" 
                    value={selectedCatalogItem ? `Purchase: ${selectedCatalogItem.name}` : analysisResult?.title}
                    onChange={(e) => setAnalysisResult(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full text-lg font-bold text-slate-800 border-b-2 border-slate-100 focus:border-indigo-500 outline-none pb-2 bg-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Vendor</label>
                  <input 
                    type="text" 
                    value={selectedCatalogItem ? selectedCatalogItem.vendorName : analysisResult?.vendorName}
                    onChange={(e) => setAnalysisResult(prev => ({ ...prev, vendorName: e.target.value }))}
                    className="w-full font-medium text-slate-700 border-b border-slate-100 focus:border-indigo-500 outline-none pb-1 bg-transparent"
                  />
                </div>
              </div>

              <div className="space-y-6">
                 <div>
                  <label className="block text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Estimated Amount</label>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-slate-400">$</span>
                    <input 
                      type="number" 
                      value={selectedCatalogItem ? selectedCatalogItem.price : (analysisResult?.amount || 0)}
                      onChange={(e) => setAnalysisResult(prev => ({ ...prev, amount: Number(e.target.value) }))}
                      className="text-3xl font-black text-slate-900 border-b-2 border-slate-100 focus:border-indigo-500 outline-none pb-2 bg-transparent w-full"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Category</label>
                  <select 
                    value={analysisResult?.category}
                    onChange={(e) => setAnalysisResult(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full p-2 bg-slate-50 rounded-lg border border-slate-200 outline-none"
                  >
                    <option>Hardware</option>
                    <option>Software</option>
                    <option>Services</option>
                    <option>Facilities</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
              <h3 className="font-bold text-indigo-900 mb-3 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5" /> AI Policy Check
              </h3>
              <div className="flex items-start gap-4">
                <div className="flex-1">
                  <p className="text-sm text-indigo-700">{analysisResult?.aiAnalysis?.complianceNotes}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {analysisResult?.aiAnalysis?.impactedDocuments?.map(doc => (
                      <span key={doc} className="px-2 py-1 bg-white border border-indigo-200 rounded text-[10px] font-bold text-indigo-600 uppercase">
                        Requires: {doc}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="text-center bg-white px-4 py-3 rounded-xl shadow-sm border border-indigo-100">
                  <div className="text-xs text-indigo-400 uppercase font-bold mb-1">Risk Score</div>
                  <div className={`text-2xl font-black ${Number(analysisResult?.aiAnalysis?.riskScore) > 60 ? 'text-red-600' : 'text-green-600'}`}>
                    {analysisResult?.aiAnalysis?.riskScore}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-8 mt-8 border-t border-slate-100">
              <button onClick={() => setStep('prompt')} className="text-slate-500 font-bold hover:text-slate-800 transition-colors">Back</button>
              <button 
                onClick={handleFinalSubmit}
                className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-bold shadow-2xl hover:bg-slate-800 transition-all active:scale-95 flex items-center gap-2"
              >
                Submit for Approval <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
