
import React, { useState } from 'react';
import { Integration } from '../types';
import { CheckCircle, RefreshCw, AlertCircle, Plug } from 'lucide-react';

interface IntegrationsProps {
  integrations: Integration[];
}

export const Integrations: React.FC<IntegrationsProps> = ({ integrations: initialIntegrations }) => {
  const [integrations, setIntegrations] = useState(initialIntegrations);

  const toggleIntegration = (id: string) => {
      setIntegrations(prev => prev.map(i => {
          if (i.id === id) {
              return {
                  ...i,
                  status: i.status === 'Connected' ? 'Disconnected' : 'Connected' as any
              }
          }
          return i;
      }));
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
       <div>
            <h2 className="text-2xl font-bold text-slate-800">Integrations</h2>
            <p className="text-slate-500">Manage connections to your ERP, HRIS, and other business systems.</p>
        </div>

        <div className="grid grid-cols-3 gap-6">
            {integrations.map(integration => (
                <div key={integration.id} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
                    {integration.status === 'Connected' && (
                        <div className="absolute top-0 right-0 bg-green-500 text-white text-[10px] font-bold px-2 py-1 rounded-bl-lg">
                            CONNECTED
                        </div>
                    )}
                    
                    <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center text-xl font-bold ${
                            integration.name === 'NetSuite' ? 'bg-blue-900 text-white' :
                            integration.name === 'Slack' ? 'bg-white border border-slate-200 text-slate-800' :
                            integration.name === 'Ironclad' ? 'bg-slate-900 text-white' :
                            'bg-indigo-100 text-indigo-600'
                        }`}>
                            {integration.name.charAt(0)}
                        </div>
                        <div>
                            <h3 className="font-bold text-slate-800">{integration.name}</h3>
                            <p className="text-xs text-slate-500 mt-1">{integration.type}</p>
                        </div>
                    </div>

                    <div className="mt-6 pt-6 border-t border-slate-100 flex justify-between items-center">
                        <div className="flex items-center gap-1.5 text-xs text-slate-500">
                            {integration.status === 'Connected' ? (
                                <>
                                    <CheckCircle className="w-3 h-3 text-green-500" /> Synced {integration.lastSync}
                                </>
                            ) : (
                                <>
                                    <AlertCircle className="w-3 h-3 text-slate-400" /> Not connected
                                </>
                            )}
                        </div>
                        <button 
                            onClick={() => toggleIntegration(integration.id)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                            integration.status === 'Connected' 
                                ? 'border-slate-200 text-slate-600 hover:bg-slate-50'
                                : 'bg-indigo-600 text-white border-transparent hover:bg-indigo-700'
                        }`}>
                            {integration.status === 'Connected' ? 'Disconnect' : 'Connect'}
                        </button>
                    </div>
                </div>
            ))}
            
             {/* Add New Integration Placeholder */}
             <div className="border-2 border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center text-slate-400 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer group p-6">
                 <Plug className="w-8 h-8 mb-2 group-hover:text-indigo-500" />
                 <span className="font-medium text-sm group-hover:text-indigo-600">Browse App Catalog</span>
             </div>
        </div>
    </div>
  );
};
