
import React, { useState } from 'react';
import { Invoice } from '../types';
import { Search, Upload, AlertCircle, CheckCircle, FileText, AlertTriangle, X } from 'lucide-react';

interface InvoicesProps {
  invoices: Invoice[];
  onAddInvoice?: (inv: Partial<Invoice>) => void;
}

export const Invoices: React.FC<InvoicesProps> = ({ invoices, onAddInvoice }) => {
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [invData, setInvData] = useState<Partial<Invoice>>({ invoiceNumber: '', vendorName: '', amount: 0 });

  const getStatusBadge = (status: string) => {
    switch(status) {
        case 'Paid': return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-green-100 text-green-800">Paid</span>;
        case 'Approved': return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">Approved</span>;
        case 'Processing': return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800">Processing</span>;
        case 'Flagged': return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-800">Flagged</span>;
        case 'Pending Approval': return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">Approval Needed</span>;
        default: return <span className="text-slate-400 font-bold">{status}</span>;
    }
  };

  const getMatchStatus = (status: string) => {
      if (status === 'Exception') {
          return <span className="flex items-center gap-1 text-red-600 font-bold text-xs"><AlertTriangle className="w-3 h-3"/> Exception</span>;
      }
      if (status === 'Pending') {
          return <span className="flex items-center gap-1 text-slate-400 font-bold text-xs">Pending...</span>;
      }
      return <span className="flex items-center gap-1 text-green-600 font-bold text-xs"><CheckCircle className="w-3 h-3"/> {status}</span>;
  };

  const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      onAddInvoice?.(invData);
      setShowUploadModal(false);
      setInvData({ invoiceNumber: '', vendorName: '', amount: 0 });
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Invoices (AP)</h2>
          <p className="text-slate-500">Automated invoice processing and 3-way matching.</p>
        </div>
        <div className="flex gap-3">
            <div className="relative">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input type="text" placeholder="Search invoices..." className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
            </div>
            <button 
                onClick={() => setShowUploadModal(true)}
                className="bg-indigo-600 text-white px-6 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 shadow-xl shadow-indigo-100 flex items-center gap-2 transition-all active:scale-95"
            >
                <Upload className="w-4 h-4" /> Upload Invoice
            </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Open Invoices</p>
              <p className="text-2xl font-black text-slate-900 mt-1">{invoices.filter(i => i.status !== 'Paid').length}</p>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Approval Required</p>
              <p className="text-2xl font-black text-amber-600 mt-1">{invoices.filter(i => i.status === 'Pending Approval').length}</p>
          </div>
           <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Matching Exceptions</p>
              <p className="text-2xl font-black text-red-600 mt-1">{invoices.filter(i => i.matchStatus === 'Exception').length}</p>
          </div>
           <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Processed (MTD)</p>
              <p className="text-2xl font-black text-green-600 mt-1">${invoices.filter(i => i.status === 'Paid').reduce((a,b) => a + b.amount, 0).toLocaleString()}</p>
          </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-widest text-[10px]">
            <tr>
              <th className="px-6 py-3">Invoice #</th>
              <th className="px-6 py-3">Vendor</th>
              <th className="px-6 py-3">PO Reference</th>
              <th className="px-6 py-3">Date</th>
              <th className="px-6 py-3">Amount</th>
              <th className="px-6 py-3">Match Status</th>
              <th className="px-6 py-3">Status</th>
              <th className="px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {invoices.map(inv => (
                <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 font-bold text-indigo-600 flex items-center gap-2">
                        <FileText className="w-4 h-4 text-slate-400"/>
                        {inv.invoiceNumber}
                    </td>
                    <td className="px-6 py-4 font-bold text-slate-900">{inv.vendorName}</td>
                    <td className="px-6 py-4 font-mono text-slate-500 text-xs">{inv.poNumber || '-'}</td>
                    <td className="px-6 py-4 text-slate-600">{new Date(inv.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4 font-black text-slate-900">${inv.amount.toLocaleString()}</td>
                    <td className="px-6 py-4">{getMatchStatus(inv.matchStatus)}</td>
                    <td className="px-6 py-4">{getStatusBadge(inv.status)}</td>
                    <td className="px-6 py-4">
                        <button className="text-indigo-600 font-bold text-xs hover:underline">Review</button>
                    </td>
                </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showUploadModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm">
              <div className="bg-white rounded-[2.5rem] p-10 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200">
                  <div className="flex justify-between items-center mb-8">
                      <h3 className="text-2xl font-black">Upload AP Invoice</h3>
                      <button onClick={() => setShowUploadModal(false)}><X className="w-6 h-6 text-slate-400 hover:text-slate-600"/></button>
                  </div>
                  <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="border-4 border-dashed border-slate-100 rounded-3xl p-10 text-center hover:bg-slate-50 transition-colors cursor-pointer group mb-6">
                          <Upload className="w-12 h-12 text-slate-300 mx-auto mb-4 group-hover:text-indigo-500 transition-colors" />
                          <p className="text-sm font-bold text-slate-500">Drop PDF here to use Gemini OCR</p>
                      </div>
                      <div>
                          <label className="block text-xs font-black uppercase text-slate-400 mb-2">Invoice Number</label>
                          <input 
                            required
                            type="text" 
                            value={invData.invoiceNumber}
                            onChange={(e) => setInvData({...invData, invoiceNumber: e.target.value})}
                            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500"
                            placeholder="INV-2024-001"
                          />
                      </div>
                      <div>
                          <label className="block text-xs font-black uppercase text-slate-400 mb-2">Vendor Name</label>
                          <input 
                            required
                            type="text" 
                            value={invData.vendorName}
                            onChange={(e) => setInvData({...invData, vendorName: e.target.value})}
                            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500"
                            placeholder="Apple Inc."
                          />
                      </div>
                      <div>
                          <label className="block text-xs font-black uppercase text-slate-400 mb-2">Total Amount</label>
                          <input 
                            required
                            type="number" 
                            value={invData.amount}
                            onChange={(e) => setInvData({...invData, amount: Number(e.target.value)})}
                            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500"
                            placeholder="1200"
                          />
                      </div>
                      <button 
                        type="submit"
                        className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black shadow-xl hover:bg-slate-800 transition-all active:scale-95"
                      >
                          Submit Invoice
                      </button>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};
