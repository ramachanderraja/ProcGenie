
import React from 'react';
import { X, Shield, FileText, CreditCard, Laptop } from 'lucide-react';

interface PolicyGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PolicyGuideModal: React.FC<PolicyGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <div>
             <h2 className="text-xl font-black text-slate-800">Procurement Policy Guide</h2>
             <p className="text-sm text-slate-500">Quick reference for approval thresholds and requirements.</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-8">
            <div className="grid grid-cols-2 gap-8">
                {/* Spending Limits */}
                <div className="col-span-2 bg-indigo-50 rounded-2xl p-6 border border-indigo-100">
                    <h3 className="font-bold text-indigo-900 flex items-center gap-2 mb-4">
                        <CreditCard className="w-5 h-5"/> Spending Thresholds
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-white p-4 rounded-xl shadow-sm border border-indigo-50">
                            <div className="text-xs font-bold text-slate-400 uppercase">Low Value</div>
                            <div className="text-xl font-black text-slate-800 mt-1">&lt; $5,000</div>
                            <p className="text-xs text-slate-500 mt-2">Manager approval only. No PO required for catalog items.</p>
                        </div>
                        <div className="bg-white p-4 rounded-xl shadow-sm border border-indigo-50">
                             <div className="text-xs font-bold text-slate-400 uppercase">Mid Value</div>
                            <div className="text-xl font-black text-slate-800 mt-1">$5k - $50k</div>
                            <p className="text-xs text-slate-500 mt-2">Finance & Dept Head approval required. 3 competitive bids recommended.</p>
                        </div>
                         <div className="bg-white p-4 rounded-xl shadow-sm border border-indigo-50">
                             <div className="text-xs font-bold text-slate-400 uppercase">High Value</div>
                            <div className="text-xl font-black text-slate-800 mt-1">&gt; $50,000</div>
                            <p className="text-xs text-slate-500 mt-2">VP & Legal review mandatory. RFP process required for new vendors.</p>
                        </div>
                    </div>
                </div>

                {/* Categories */}
                <div className="space-y-6">
                    <div>
                        <h3 className="font-bold text-slate-800 flex items-center gap-2 mb-3">
                            <Laptop className="w-5 h-5 text-indigo-600"/> Hardware & IT Equipment
                        </h3>
                        <ul className="space-y-3">
                            <li className="flex gap-3 text-sm text-slate-600">
                                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-2 shrink-0"></span>
                                Standard laptops and monitors must be ordered via the IT Catalog.
                            </li>
                             <li className="flex gap-3 text-sm text-slate-600">
                                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-2 shrink-0"></span>
                                Non-standard equipment requires IT Director approval and business justification.
                            </li>
                        </ul>
                    </div>

                     <div>
                        <h3 className="font-bold text-slate-800 flex items-center gap-2 mb-3">
                            <Shield className="w-5 h-5 text-emerald-600"/> Software & SaaS
                        </h3>
                         <ul className="space-y-3">
                            <li className="flex gap-3 text-sm text-slate-600">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0"></span>
                                All new software subscriptions require a Security Risk Assessment.
                            </li>
                             <li className="flex gap-3 text-sm text-slate-600">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0"></span>
                                Personal credit cards are NOT allowed for recurring SaaS payments.
                            </li>
                        </ul>
                    </div>
                </div>

                <div className="space-y-6">
                     <div>
                        <h3 className="font-bold text-slate-800 flex items-center gap-2 mb-3">
                            <FileText className="w-5 h-5 text-amber-600"/> Professional Services
                        </h3>
                        <ul className="space-y-3">
                            <li className="flex gap-3 text-sm text-slate-600">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0"></span>
                                Statement of Work (SOW) must be signed before work begins.
                            </li>
                             <li className="flex gap-3 text-sm text-slate-600">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0"></span>
                                Contractors must complete background checks if accessing internal systems.
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end">
            <button onClick={onClose} className="px-6 py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors">
                Close Guide
            </button>
        </div>
      </div>
    </div>
  );
};
