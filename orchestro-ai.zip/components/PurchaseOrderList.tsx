
import React from 'react';
import { PurchaseOrder } from '../types';
import { FileText, Download, ExternalLink, CheckCircle, Truck, CreditCard } from 'lucide-react';

interface PurchaseOrderListProps {
  purchaseOrders: PurchaseOrder[];
}

export const PurchaseOrderList: React.FC<PurchaseOrderListProps> = ({ purchaseOrders }) => {
  const getStatusBadge = (status: PurchaseOrder['status']) => {
    switch (status) {
        case 'Sent': return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"><FileText className="w-3 h-3"/> Sent</span>;
        case 'Fulfilled': return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800"><Truck className="w-3 h-3"/> Fulfilled</span>;
        case 'Paid': return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800"><CreditCard className="w-3 h-3"/> Paid</span>;
        default: return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800">{status}</span>;
    }
  };

  const handleDownload = (poNumber: string) => {
    alert(`Downloading PO #${poNumber} as PDF...`);
  };

  const handleViewDetails = (poNumber: string) => {
    alert(`Opening details for PO #${poNumber}...`);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
        <div>
            <h2 className="text-2xl font-bold text-slate-800">Purchase Orders</h2>
            <p className="text-slate-500">Track issued POs, goods receipts, and payments.</p>
        </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50 text-slate-500 font-medium">
              <tr>
                <th className="px-6 py-3">PO Number</th>
                <th className="px-6 py-3">Vendor</th>
                <th className="px-6 py-3">Created Date</th>
                <th className="px-6 py-3">Amount</th>
                <th className="px-6 py-3">Status</th>
                <th className="px-6 py-3">Request Ref</th>
                <th className="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {purchaseOrders.map((po) => (
                <tr key={po.poNumber} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-4 font-mono font-medium text-indigo-600">{po.poNumber}</td>
                  <td className="px-6 py-4 font-medium text-slate-900">{po.vendorName}</td>
                  <td className="px-6 py-4 text-slate-600">{new Date(po.createdAt).toLocaleDateString()}</td>
                  <td className="px-6 py-4 text-slate-900">{po.currency} {po.amount.toLocaleString()}</td>
                  <td className="px-6 py-4">{getStatusBadge(po.status)}</td>
                  <td className="px-6 py-4 font-mono text-xs text-slate-500">{po.requestId}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                            onClick={() => handleDownload(po.poNumber)}
                            className="p-1 text-slate-400 hover:text-indigo-600" 
                            title="Download PDF"
                        >
                            <Download className="w-4 h-4" />
                        </button>
                         <button 
                            onClick={() => handleViewDetails(po.poNumber)}
                            className="p-1 text-slate-400 hover:text-indigo-600" 
                            title="View Details"
                        >
                            <ExternalLink className="w-4 h-4" />
                        </button>
                    </div>
                  </td>
                </tr>
              ))}
              {purchaseOrders.length === 0 && (
                  <tr>
                      <td colSpan={7} className="text-center py-8 text-slate-500">No purchase orders generated yet.</td>
                  </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
