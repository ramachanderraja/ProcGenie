
import React, { useEffect, useState, useRef } from 'react';
import { ProcurementRequest, AIAnalysis, RequestStatus, Comment, PurchaseOrder } from '../types';
import { GeminiService } from '../services/gemini';
import { 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  FileText, 
  Building2, 
  DollarSign,
  Loader2,
  ArrowLeft,
  User,
  Shield,
  Scale,
  MessageSquare,
  Send,
  FileCheck,
  Truck,
  CreditCard,
  PackageCheck,
  ChevronRight,
  AtSign,
  Paperclip,
  Clock,
  ChevronLeft
} from 'lucide-react';

interface RequestDetailProps {
  request: ProcurementRequest;
  onBack: () => void;
  onStatusChange: (id: string, status: RequestStatus) => void;
  onCreatePO: (request: ProcurementRequest) => void;
  purchaseOrder?: PurchaseOrder;
}

export const RequestDetail: React.FC<RequestDetailProps> = ({ request, onBack, onStatusChange, onCreatePO, purchaseOrder }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'discussion' | 'workflow'>('overview');
  const [newComment, setNewComment] = useState('');
  const [comments, setComments] = useState<Comment[]>(request.comments || []);
  const commentsEndRef = useRef<HTMLDivElement>(null);

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    const comment: Comment = {
      id: Date.now().toString(),
      author: 'Alex Comptroller',
      text: newComment,
      timestamp: new Date().toISOString(),
      role: 'Finance Manager'
    };
    setComments([...comments, comment]);
    setNewComment('');
  };

  const getStepStatusStyles = (status: string) => {
    switch(status) {
      case 'approved': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'current': return 'bg-indigo-100 text-indigo-700 border-indigo-200 ring-2 ring-indigo-500 animate-pulse';
      case 'rejected': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-slate-50 text-slate-400 border-slate-100';
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-50">
      {/* Dynamic Header */}
      <div className="bg-white border-b border-slate-200 px-8 py-6 flex justify-between items-center sticky top-0 z-30 shadow-sm">
        <div className="flex items-center gap-6">
          <button onClick={onBack} className="p-3 hover:bg-slate-100 rounded-2xl text-slate-500 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-black text-slate-900">{request.title}</h1>
              <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-bold uppercase tracking-widest border border-slate-200">
                {request.id}
              </span>
            </div>
            <div className="flex items-center gap-4 mt-2 text-sm text-slate-500">
              <span className="flex items-center gap-1.5 font-medium"><User className="w-4 h-4" /> {request.requester}</span>
              <span>•</span>
              <span className="flex items-center gap-1.5"><Building2 className="w-4 h-4" /> {request.department}</span>
              <span>•</span>
              <span className="flex items-center gap-1.5"><Clock className="w-4 h-4" /> {new Date(request.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {request.status === RequestStatus.PENDING_APPROVAL && (
            <>
              <button 
                onClick={() => onStatusChange(request.id, RequestStatus.REJECTED)}
                className="px-6 py-2.5 text-red-600 font-bold hover:bg-red-50 rounded-xl transition-all"
              >
                Reject
              </button>
              <button 
                onClick={() => onStatusChange(request.id, RequestStatus.APPROVED)}
                className="px-8 py-2.5 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 shadow-xl shadow-slate-200 transition-all active:scale-95"
              >
                Approve Request
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Flow Stepper (Use Case 2f) */}
      <div className="bg-white border-b border-slate-200 px-8 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between relative">
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -translate-y-1/2 -z-10"></div>
          {request.approvalSteps.map((step, i) => (
            <div key={step.id} className="flex flex-col items-center gap-3 bg-white px-4">
              <div className={`w-10 h-10 rounded-full border-4 flex items-center justify-center transition-all ${getStepStatusStyles(step.status)}`}>
                {step.status === 'approved' ? <CheckCircle className="w-5 h-5" /> : <span className="text-sm font-black">{i + 1}</span>}
              </div>
              <span className={`text-xs font-bold uppercase tracking-wider ${step.status === 'current' ? 'text-indigo-600' : 'text-slate-400'}`}>
                {step.name}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="p-8 overflow-y-auto max-w-7xl mx-auto w-full flex gap-8 h-full">
        {/* Left Side: Content */}
        <div className="flex-1 space-y-8">
           <div className="flex gap-4 p-1 bg-slate-200/50 rounded-2xl w-fit">
              {['overview', 'discussion', 'workflow'].map(tab => (
                <button 
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={`px-6 py-2 rounded-xl text-sm font-bold transition-all capitalize ${activeTab === tab ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  {tab}
                </button>
              ))}
           </div>

           {activeTab === 'overview' && (
             <div className="space-y-6 animate-in fade-in duration-300">
                <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-8">
                   <div className="grid grid-cols-3 gap-8">
                      <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                        <div className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Amount</div>
                        <div className="text-3xl font-black text-slate-900">${request.amount.toLocaleString()}</div>
                        <div className="text-xs text-slate-500 mt-1">{request.currency} • Total Estimate</div>
                      </div>
                      <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                        <div className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Vendor</div>
                        <div className="text-xl font-bold text-slate-900">{request.vendorName}</div>
                        <div className="text-xs text-indigo-600 font-bold mt-1 uppercase tracking-tighter cursor-pointer hover:underline">View Vendor Profile</div>
                      </div>
                      <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                        <div className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Risk Status</div>
                        <div className="flex items-center gap-2">
                           <ShieldCheck className="w-6 h-6 text-emerald-500" />
                           <span className="text-xl font-bold text-emerald-600">Low Risk</span>
                        </div>
                        <div className="text-xs text-slate-500 mt-1">Verified via Gemini AI</div>
                      </div>
                   </div>

                   <div className="border-t border-slate-100 pt-8">
                      <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4">Description & Justification</h3>
                      <p className="text-slate-800 leading-relaxed text-lg">{request.description}</p>
                      <div className="mt-6 p-6 bg-indigo-50/50 rounded-2xl border border-indigo-100 italic text-indigo-900">
                        "{request.businessJustification}"
                      </div>
                   </div>

                   <div className="border-t border-slate-100 pt-8">
                      <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4">Impacted Documents</h3>
                      <div className="flex flex-wrap gap-4">
                         {request.aiAnalysis?.impactedDocuments.map(doc => (
                           <div key={doc} className="flex items-center gap-3 p-4 bg-white border border-slate-200 rounded-2xl hover:border-indigo-500 cursor-pointer transition-all group">
                              <FileText className="w-6 h-6 text-slate-400 group-hover:text-indigo-600" />
                              <div>
                                <div className="text-sm font-bold text-slate-800">{doc}</div>
                                <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Draft Created</div>
                              </div>
                              <ChevronRight className="w-4 h-4 text-slate-300 ml-4" />
                           </div>
                         ))}
                      </div>
                   </div>
                </div>
             </div>
           )}

           {activeTab === 'discussion' && (
             <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[600px] animate-in slide-in-from-right-4">
                <div className="flex-1 overflow-y-auto p-8 space-y-8 bg-slate-50/30">
                  {comments.map(c => (
                    <div key={c.id} className="flex gap-4">
                      <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-500 flex-shrink-0">
                        {c.author.substring(0,1)}
                      </div>
                      <div>
                        <div className="flex items-center gap-3 mb-1.5">
                          <span className="font-bold text-slate-900">{c.author}</span>
                          <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">{c.role}</span>
                          <span className="text-xs text-slate-400">{new Date(c.timestamp).toLocaleTimeString()}</span>
                        </div>
                        <div className="bg-white p-4 rounded-2xl border border-slate-200 text-slate-700 shadow-sm leading-relaxed">
                          {c.text}
                        </div>
                        <div className="flex gap-4 mt-2">
                           <button className="text-[10px] font-bold text-indigo-600 hover:underline">Reply</button>
                           <button className="text-[10px] font-bold text-slate-400 hover:underline">React</button>
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={commentsEndRef} />
                </div>
                <div className="p-6 bg-white border-t border-slate-100">
                  <div className="relative">
                    <textarea 
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Share a thought, tag a colleague with @, or attach a file..."
                      className="w-full h-24 p-4 pr-32 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500 transition-all resize-none text-slate-700"
                    />
                    <div className="absolute bottom-4 right-4 flex gap-2">
                      <button className="p-2 text-slate-400 hover:bg-slate-100 rounded-xl transition-colors"><AtSign className="w-5 h-5"/></button>
                      <button className="p-2 text-slate-400 hover:bg-slate-100 rounded-xl transition-colors"><Paperclip className="w-5 h-5"/></button>
                      <button 
                        onClick={handleAddComment}
                        className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-lg shadow-indigo-100 active:scale-95 transition-all"
                      >
                        Send
                      </button>
                    </div>
                  </div>
                </div>
             </div>
           )}

           {activeTab === 'workflow' && (
             <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm animate-in fade-in">
                <h3 className="text-xl font-black text-slate-900 mb-8">Workflow Engine</h3>
                <div className="space-y-12 relative">
                  <div className="absolute left-6 top-8 bottom-8 w-1 bg-slate-100 -z-10"></div>
                  {request.approvalSteps.map(step => (
                    <div key={step.id} className="flex gap-8 items-start group">
                      <div className={`w-12 h-12 rounded-full border-4 flex items-center justify-center bg-white z-10 transition-all ${getStepStatusStyles(step.status)}`}>
                        {step.status === 'approved' ? <CheckCircle className="w-6 h-6" /> : <User className="w-6 h-6" />}
                      </div>
                      <div className="flex-1 pb-4 border-b border-slate-50">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-black text-slate-900 text-lg">{step.name}</h4>
                            <p className="text-sm text-slate-500 mt-0.5">{step.role} Approval Tier</p>
                          </div>
                          <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border ${getStepStatusStyles(step.status)}`}>
                            {step.status}
                          </span>
                        </div>
                        {step.approverName && (
                          <div className="mt-4 flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold">{step.approverName.substring(0,1)}</div>
                            <span className="text-sm font-bold text-slate-700">{step.approverName}</span>
                            <span className="text-xs text-slate-400">Decision made at {step.timestamp ? new Date(step.timestamp).toLocaleTimeString() : 'N/A'}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
             </div>
           )}
        </div>

        {/* Right Side: Insights (Use Case 2b) */}
        <div className="w-96 space-y-6">
           <div className="bg-slate-900 text-white rounded-3xl p-8 shadow-2xl">
              <h4 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-6">Process Insights</h4>
              <div className="space-y-8">
                <div>
                   <div className="flex justify-between text-xs font-bold uppercase tracking-widest mb-2">
                      <span>Approval Velocity</span>
                      <span className="text-emerald-400">Faster than average</span>
                   </div>
                   <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 w-[85%]"></div>
                   </div>
                   <p className="text-[10px] text-slate-500 mt-2">Avg. turnaround: 1.2h / Expected: 4h</p>
                </div>
                
                <div className="pt-6 border-t border-slate-800">
                   <div className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Current Bottleneck</div>
                   <div className="flex items-center gap-4 p-4 bg-slate-800 rounded-2xl border border-slate-700">
                      <div className="w-10 h-10 rounded-full bg-amber-500/10 text-amber-500 flex items-center justify-center"><AlertTriangle className="w-5 h-5"/></div>
                      <div>
                        <div className="text-sm font-bold">Finance Queue</div>
                        <div className="text-[10px] text-slate-500">32 requests ahead of yours</div>
                      </div>
                   </div>
                   <button className="w-full mt-4 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold transition-all">Nudge Approver</button>
                </div>
              </div>
           </div>

           <div className="bg-white rounded-3xl p-8 border border-slate-200">
              <h4 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-6">Recent Activity</h4>
              <div className="space-y-6">
                 {[1,2].map(i => (
                   <div key={i} className="flex gap-4">
                      <div className="w-1 h-8 bg-indigo-500 rounded-full"></div>
                      <div>
                         <div className="text-xs font-bold text-slate-800">System generated MSA draft</div>
                         <div className="text-[10px] text-slate-400 mt-1">2 hours ago</div>
                      </div>
                   </div>
                 ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
