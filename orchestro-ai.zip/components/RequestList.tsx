import React from 'react';
import { ProcurementRequest, RequestStatus, Priority } from '../types';
import { Eye, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

interface RequestListProps {
  requests: ProcurementRequest[];
  onSelect: (request: ProcurementRequest) => void;
}

export const RequestList: React.FC<RequestListProps> = ({ requests, onSelect }) => {
  const getStatusBadge = (status: RequestStatus) => {
    switch (status) {
      case RequestStatus.APPROVED:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" /> Approved</span>;
      case RequestStatus.REJECTED:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800"><XCircle className="w-3 h-3 mr-1" /> Rejected</span>;
      case RequestStatus.PENDING_APPROVAL:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"><Clock className="w-3 h-3 mr-1" /> Approval</span>;
      default:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"><AlertCircle className="w-3 h-3 mr-1" /> {status}</span>;
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
        <h3 className="font-bold text-slate-800">Recent Requests</h3>
        <button className="text-sm text-indigo-600 hover:text-indigo-700 font-medium">View All</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 font-medium">
            <tr>
              <th className="px-6 py-3">Request ID</th>
              <th className="px-6 py-3">Title</th>
              <th className="px-6 py-3">Vendor</th>
              <th className="px-6 py-3">Amount</th>
              <th className="px-6 py-3">Status</th>
              <th className="px-6 py-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {requests.map((req) => (
              <tr key={req.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4 font-mono text-slate-500">{req.id}</td>
                <td className="px-6 py-4 font-medium text-slate-900">{req.title}</td>
                <td className="px-6 py-4 text-slate-600">{req.vendorName}</td>
                <td className="px-6 py-4 text-slate-900 font-medium">{req.currency} {req.amount.toLocaleString()}</td>
                <td className="px-6 py-4">{getStatusBadge(req.status)}</td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => onSelect(req)}
                    className="text-slate-400 hover:text-indigo-600 transition-colors"
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
            {requests.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-slate-500">
                  No requests found. Start a new one!
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};