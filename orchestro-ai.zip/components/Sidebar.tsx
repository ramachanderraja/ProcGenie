
import React from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  FileText, 
  Settings, 
  LogOut,
  Box,
  Inbox,
  FileCheck,
  Target,
  Receipt,
  PieChart,
  Link2,
  ScrollText
} from 'lucide-react';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  pendingApprovalCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeView, onNavigate, pendingApprovalCount = 0 }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'intake', label: 'New Request', icon: PlusCircle },
    { id: 'approvals', label: 'My Approvals', icon: Inbox, badge: pendingApprovalCount },
    { id: 'requests', label: 'My Requests', icon: FileText },
    { id: 'contracts', label: 'Contracts', icon: ScrollText },
    { id: 'sourcing', label: 'Sourcing', icon: Target },
    { id: 'purchase-orders', label: 'Purchase Orders', icon: FileCheck },
    { id: 'invoices', label: 'Invoices', icon: Receipt },
    { id: 'vendors', label: 'Vendors', icon: Box },
    { id: 'insights', label: 'Insights', icon: PieChart },
  ];

  const handleSignOut = () => {
    if (window.confirm("Are you sure you want to sign out?")) {
      window.location.reload(); // Simulate sign out
    }
  };

  return (
    <div className="w-64 bg-white border-r border-slate-200 h-screen flex flex-col sticky top-0 z-40">
      <div className="p-6 flex items-center gap-2 border-b border-slate-100">
        <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-200">
          <span className="text-white font-bold text-xl">O</span>
        </div>
        <span className="font-bold text-slate-800 text-lg tracking-tight">Orchestro</span>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`w-full flex items-center justify-between px-4 py-3 text-sm font-medium rounded-lg transition-all ${
              activeView === item.id
                ? 'bg-indigo-50 text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <item.icon className={`w-5 h-5 ${activeView === item.id ? 'text-indigo-600' : 'text-slate-400'}`} />
              {item.label}
            </div>
            {item.badge ? (
              <span className="bg-indigo-600 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                {item.badge}
              </span>
            ) : null}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-100">
        <button 
          onClick={() => onNavigate('integrations')}
          className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
            activeView === 'integrations' 
              ? 'bg-indigo-50 text-indigo-700' 
              : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
          }`}
        >
          <Link2 className="w-5 h-5 text-slate-400" />
          Integrations
        </button>
        <button 
          onClick={() => alert("Settings panel is under construction.")}
          className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-50 transition-colors"
        >
          <Settings className="w-5 h-5 text-slate-400" />
          Settings
        </button>
        <button 
          onClick={handleSignOut}
          className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors mt-1"
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </div>
    </div>
  );
};
