
import React, { useState } from 'react';
import { SourcingProject } from '../types';
import { Plus, Filter, ChevronRight, Users, DollarSign, Calendar, X } from 'lucide-react';

interface SourcingProps {
  projects: SourcingProject[];
  onAddProject?: (title: string, budget: number) => void;
}

export const Sourcing: React.FC<SourcingProps> = ({ projects, onAddProject }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newBudget, setNewBudget] = useState(0);

  const getStatusColor = (status: string) => {
    switch(status) {
        case 'Active': return 'bg-green-100 text-green-800';
        case 'Draft': return 'bg-slate-100 text-slate-800';
        case 'Selection': return 'bg-blue-100 text-blue-800';
        case 'Closed': return 'bg-slate-200 text-slate-500';
        default: return 'bg-slate-100 text-slate-800';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      onAddProject?.(newTitle, newBudget);
      setShowAddModal(false);
      setNewTitle('');
      setNewBudget(0);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Sourcing & RFPs</h2>
          <p className="text-slate-500">Manage competitive bidding and renewals to drive savings.</p>
        </div>
        <button 
            onClick={() => setShowAddModal(true)}
            className="bg-indigo-600 text-white px-6 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 shadow-xl shadow-indigo-100 flex items-center gap-2 transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" /> Create Event
        </button>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg"><DollarSign className="w-5 h-5"/></div>
                <span className="text-sm font-medium text-slate-500">Potential Savings</span>
            </div>
            <div className="text-2xl font-bold text-slate-800">$142,000</div>
            <div className="text-xs text-green-600 mt-1">↑ Across 3 active events</div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
             <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg"><Users className="w-5 h-5"/></div>
                <span className="text-sm font-medium text-slate-500">Active Projects</span>
            </div>
            <div className="text-2xl font-bold text-slate-800">{projects.filter(p => p.status === 'Active' || p.status === 'Selection').length}</div>
            <div className="text-xs text-slate-500 mt-1">2 Renewals, 1 RFP</div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
             <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-amber-50 text-amber-600 rounded-lg"><Calendar className="w-5 h-5"/></div>
                <span className="text-sm font-medium text-slate-500">Upcoming Renewals</span>
            </div>
            <div className="text-2xl font-bold text-slate-800">5</div>
            <div className="text-xs text-amber-600 mt-1">Action needed in 30 days</div>
        </div>
      </div>

      {/* Projects List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
         <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <h3 className="font-bold text-slate-800">Active Sourcing Events</h3>
            <button className="text-slate-500 hover:text-indigo-600"><Filter className="w-4 h-4"/></button>
         </div>
         <table className="w-full text-sm text-left">
            <thead className="text-slate-500 font-medium bg-slate-50">
                <tr>
                    <th className="px-6 py-3">Project Name</th>
                    <th className="px-6 py-3">Type</th>
                    <th className="px-6 py-3">Status</th>
                    <th className="px-6 py-3">Budget</th>
                    <th className="px-6 py-3">Vendors</th>
                    <th className="px-6 py-3">Due Date</th>
                    <th className="px-6 py-3"></th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
                {projects.map(project => (
                    <tr key={project.id} className="hover:bg-slate-50 transition-colors cursor-pointer group">
                        <td className="px-6 py-4">
                            <div className="font-bold text-slate-900">{project.title}</div>
                            <div className="text-xs text-slate-500">Owner: {project.owner}</div>
                        </td>
                        <td className="px-6 py-4">
                             <span className="inline-block px-2 py-1 bg-slate-100 text-slate-600 rounded text-xs font-bold border border-slate-200">
                                {project.type}
                             </span>
                        </td>
                        <td className="px-6 py-4">
                             <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold ${getStatusColor(project.status)}`}>
                                {project.status}
                             </span>
                        </td>
                        <td className="px-6 py-4 text-slate-600 font-mono font-bold">
                            ${project.budget.toLocaleString()}
                        </td>
                        <td className="px-6 py-4">
                            <div className="flex -space-x-2">
                                {project.vendors.map((v, i) => (
                                    <div key={i} className="w-6 h-6 rounded-full bg-indigo-100 border-2 border-white flex items-center justify-center text-[10px] font-bold text-indigo-600" title={v}>
                                        {v.charAt(0)}
                                    </div>
                                ))}
                                {project.vendors.length === 0 && <span className="text-slate-400 italic">None invited</span>}
                            </div>
                        </td>
                        <td className="px-6 py-4 text-slate-600">
                            {new Date(project.dueDate).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-right">
                            <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-indigo-600 transition-colors" />
                        </td>
                    </tr>
                ))}
            </tbody>
         </table>
      </div>

      {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm">
              <div className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-black">New Sourcing Project</h3>
                      <button onClick={() => setShowAddModal(false)}><X className="w-6 h-6 text-slate-400 hover:text-slate-600"/></button>
                  </div>
                  <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                          <label className="block text-xs font-black uppercase text-slate-400 mb-2">Project Title</label>
                          <input 
                            required
                            type="text" 
                            value={newTitle}
                            onChange={(e) => setNewTitle(e.target.value)}
                            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500"
                            placeholder="e.g., Q1 Laptop Refresh RFP"
                          />
                      </div>
                      <div>
                          <label className="block text-xs font-black uppercase text-slate-400 mb-2">Estimated Budget</label>
                          <input 
                            required
                            type="number" 
                            value={newBudget}
                            onChange={(e) => setNewBudget(Number(e.target.value))}
                            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500"
                            placeholder="50000"
                          />
                      </div>
                      <button 
                        type="submit"
                        className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95"
                      >
                          Create Project
                      </button>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};
