


import React, { useState } from 'react';
import { Vendor, ProcurementRequest, Contract } from '../types';
import { 
  ArrowLeft, 
  Globe, 
  Mail, 
  ExternalLink, 
  ShieldCheck, 
  TrendingUp, 
  CheckCircle,
  FileText,
  Edit2,
  Save,
  X,
  Trash2,
  AlertTriangle,
  Bell,
  Activity,
  DollarSign,
  Clock,
  Landmark,
  FileCheck,
  AlertOctagon,
  Download
} from 'lucide-react';

interface VendorDetailProps {
  vendor: Vendor;
  onBack: () => void;
  allRequests: ProcurementRequest[];
  onSelectRequest: (req: ProcurementRequest) => void;
  onUpdateVendor: (vendor: Vendor) => void;
  onEdit?: () => void;
  onDelete?: () => void;
}

export const VendorDetail: React.FC<VendorDetailProps> = ({ vendor, onBack, allRequests, onSelectRequest, onUpdateVendor, onEdit, onDelete }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Contract>>({});

  const getRelatedRequest = (id?: string) => {
    if (!id) return null;
    return allRequests.find(r => r.id === id);
  };

  const getDaysRemaining = (dateStr: string) => {
    const end = new Date(dateStr);
    const now = new Date();
    const diff = end.getTime() - now.getTime();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  const upcomingRenewals = vendor.contracts.filter(c => {
      const days = getDaysRemaining(c.endDate);
      return days >= 0 && days <= 30 && c.status !== 'Expired';
  });

  const startEdit = (contract: Contract) => {
    setEditingId(contract.id);
    setEditForm({ ...contract });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({});
  };

  const saveEdit = () => {
    if (!editingId) return;
    
    const updatedContracts = vendor.contracts.map(c => 
      c.id === editingId ? { ...c, ...editForm } as Contract : c
    );
    
    onUpdateVendor({
        ...vendor,
        contracts: updatedContracts
    });
    setEditingId(null);
    setEditForm({});
  };

  // Mock Trust Factors based on main score
  const trustFactors = [
    { 
      label: 'On-time Delivery', 
      score: Math.min(100, Math.max(50, vendor.trustScore + (vendor.trustScore > 85 ? 2 : -8))), 
      icon: Clock,
      color: 'text-blue-600',
      barColor: 'bg-blue-500'
    },
    { 
      label: 'Quality Compliance', 
      score: Math.min(100, Math.max(50, vendor.trustScore + (vendor.trustScore > 85 ? -1 : 5))), 
      icon: ShieldCheck,
      color: 'text-indigo-600',
      barColor: 'bg-indigo-500'
    },
    { 
      label: 'Financial Stability', 
      score: Math.min(100, Math.max(50, vendor.trustScore + (vendor.trustScore > 85 ? 4 : -2))), 
      icon: DollarSign,
      color: 'text-green-600',
      barColor: 'bg-green-500'
    }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <button onClick={onBack} className="flex items-center text-slate-500 hover:text-slate-800 transition-colors mb-2">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to Vendors
      </button>

      {/* Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex justify-between items-start">
        <div className="flex gap-4">
           <div className="w-16 h-16 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-2xl border border-indigo-100">
                {vendor.name.substring(0, 2).toUpperCase()}
           </div>
           <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold text-slate-800">{vendor.name}</h1>
                {vendor.isPreferred && (
                    <span className="px-2 py-0.5 bg-green-50 text-green-700 border border-green-200 rounded-full text-xs font-medium flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> Preferred Partner
                    </span>
                )}
                {vendor.complianceStatus?.taxValid === 'Verified' && (
                    <span className="px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded-full text-xs font-medium flex items-center gap-1">
                        <FileCheck className="w-3 h-3" /> Tax Verified
                    </span>
                )}
                {vendor.complianceStatus?.bankValid === 'Verified' && (
                    <span className="px-2 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded-full text-xs font-medium flex items-center gap-1">
                        <Landmark className="w-3 h-3" /> Bank Verified
                    </span>
                )}
              </div>
              <p className="text-slate-500 mt-1">{vendor.category} • ID: {vendor.id}</p>
              
              <div className="flex gap-4 mt-3 text-sm text-slate-600">
                 <a href={`https://${vendor.website}`} target="_blank" rel="noreferrer" className="flex items-center hover:text-indigo-600 gap-1.5 transition-colors">
                    <Globe className="w-4 h-4" /> {vendor.website}
                 </a>
                 <span className="flex items-center gap-1.5"><Mail className="w-4 h-4" /> {vendor.contactEmail}</span>
              </div>
           </div>
        </div>
        <div className="flex flex-col items-end gap-2">
            <div className="flex gap-2">
                <button 
                    onClick={onEdit}
                    className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2 transition-colors"
                >
                    <Edit2 className="w-4 h-4" /> Edit
                </button>
                 <button 
                    onClick={onDelete}
                    className="px-3 py-1.5 bg-white border border-red-200 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 flex items-center gap-2 transition-colors"
                >
                    <Trash2 className="w-4 h-4" /> Delete
                </button>
            </div>
             <div className="text-right mt-2">
                <div className="text-sm text-slate-500">Annual Spend</div>
                <div className="text-2xl font-bold text-slate-800">${vendor.spendLast12M.toLocaleString()}</div>
            </div>
        </div>
      </div>

      {/* Onboarding Tracker (if incomplete) */}
      {vendor.onboardingStatus !== 'Complete' && vendor.onboardingSteps && (
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm animate-in fade-in slide-in-from-top-2">
              <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-indigo-600"/> Onboarding Status: {vendor.onboardingStatus}
              </h3>
              <div className="flex items-center justify-between relative px-8">
                   <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -z-10"></div>
                   {vendor.onboardingSteps.map((step, index) => (
                       <div key={index} className="flex flex-col items-center gap-2 bg-white px-2">
                           <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${
                               step.status === 'completed' ? 'bg-green-100 border-green-500 text-green-600' :
                               step.status === 'current' ? 'bg-blue-100 border-blue-500 text-blue-600 animate-pulse' :
                               'bg-slate-50 border-slate-200 text-slate-400'
                           }`}>
                               {step.status === 'completed' ? <CheckCircle className="w-4 h-4"/> : 
                                step.status === 'current' ? <Clock className="w-4 h-4"/> : 
                                <span className="text-xs font-bold">{index + 1}</span>}
                           </div>
                           <span className={`text-xs font-medium ${step.status === 'current' ? 'text-blue-600' : 'text-slate-600'}`}>{step.name}</span>
                       </div>
                   ))}
              </div>
          </div>
      )}

      {/* Renewal Notification Banner */}
      {upcomingRenewals.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 animate-in fade-in slide-in-from-top-2 shadow-sm">
            <div className="p-2 bg-amber-100 rounded-lg text-amber-600 mt-0.5">
                <Bell className="w-5 h-5" />
            </div>
            <div className="flex-1">
                <h4 className="font-bold text-amber-900">Action Required: Upcoming Contract Renewals</h4>
                <p className="text-sm text-amber-700 mt-1">
                    {upcomingRenewals.length} contract(s) are set to expire within the next 30 days. Please review terms and initiate renewal or cancellation.
                </p>
            </div>
        </div>
      )}

      <div className="grid grid-cols-3 gap-6">
        {/* Left Column: Details & Performance */}
        <div className="col-span-2 space-y-6">
            
            {/* Description */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-slate-800 mb-3">About</h3>
                <p className="text-slate-600 leading-relaxed text-sm">
                    {vendor.description}
                </p>
                
                <div className="mt-6 grid grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-50 rounded-lg border border-slate-100">
                        <h4 className="text-xs font-semibold text-slate-500 uppercase mb-2">Primary Contact</h4>
                        <p className="font-medium text-slate-900">{vendor.contactName}</p>
                        <p className="text-sm text-slate-500">{vendor.contactEmail}</p>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-lg border border-slate-100">
                        <h4 className="text-xs font-semibold text-slate-500 uppercase mb-2">Security Status</h4>
                         <div className="flex items-center gap-2 text-green-700 font-medium text-sm">
                            <ShieldCheck className="w-4 h-4" /> SOC2 Compliant
                         </div>
                         <p className="text-xs text-slate-500 mt-1">Last audited: Oct 2023</p>
                    </div>
                </div>
            </div>

            {/* Compliance & Risk Console */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-100">
                    <h3 className="font-bold text-slate-800 flex items-center gap-2">
                        <ShieldCheck className="w-5 h-5 text-indigo-600"/> Compliance & Risk Console
                    </h3>
                </div>
                
                <div className="grid grid-cols-2 gap-6 p-6">
                     {/* Automated Checks */}
                     <div className="space-y-4">
                         <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Automated Validations</h4>
                         
                         <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                             <div className="flex items-center gap-3">
                                 <Landmark className="w-4 h-4 text-slate-500" />
                                 <span className="text-sm font-medium text-slate-700">Bank Verification</span>
                             </div>
                             {vendor.complianceStatus?.bankValid === 'Verified' ? (
                                 <span className="flex items-center gap-1 text-xs font-medium text-green-700 bg-green-100 px-2 py-0.5 rounded-full"><CheckCircle className="w-3 h-3"/> Verified</span>
                             ) : (
                                 <span className="flex items-center gap-1 text-xs font-medium text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full"><Clock className="w-3 h-3"/> Pending</span>
                             )}
                         </div>

                          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                             <div className="flex items-center gap-3">
                                 <FileCheck className="w-4 h-4 text-slate-500" />
                                 <span className="text-sm font-medium text-slate-700">Tax ID Validation</span>
                             </div>
                             {vendor.complianceStatus?.taxValid === 'Verified' ? (
                                 <span className="flex items-center gap-1 text-xs font-medium text-green-700 bg-green-100 px-2 py-0.5 rounded-full"><CheckCircle className="w-3 h-3"/> Verified</span>
                             ) : (
                                 <span className="flex items-center gap-1 text-xs font-medium text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full"><Clock className="w-3 h-3"/> Pending</span>
                             )}
                         </div>

                          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                             <div className="flex items-center gap-3">
                                 <Globe className="w-4 h-4 text-slate-500" />
                                 <span className="text-sm font-medium text-slate-700">Sanctions Check</span>
                             </div>
                             {vendor.complianceStatus?.sanctionsCheck === 'Passed' ? (
                                 <span className="flex items-center gap-1 text-xs font-medium text-green-700 bg-green-100 px-2 py-0.5 rounded-full"><CheckCircle className="w-3 h-3"/> Passed</span>
                             ) : (
                                 <span className="flex items-center gap-1 text-xs font-medium text-red-700 bg-red-100 px-2 py-0.5 rounded-full"><AlertTriangle className="w-3 h-3"/> Flagged</span>
                             )}
                         </div>
                     </div>

                     {/* AI Risk Scan */}
                     <div className="space-y-4">
                         <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
                             Supplier Risk Scan <span className="bg-indigo-100 text-indigo-700 px-1.5 rounded text-[10px]">AI</span>
                         </h4>
                         
                         <div className="p-4 bg-gradient-to-br from-indigo-50 to-white rounded-lg border border-indigo-100">
                             <div className="flex items-center gap-2 mb-2">
                                 <Activity className="w-4 h-4 text-indigo-600" />
                                 <span className="text-sm font-bold text-indigo-900">Live Monitor</span>
                             </div>
                             <div className="text-xs text-slate-600 mb-2">
                                 Last scanned: {vendor.riskScan?.lastScanned || 'Today'}
                             </div>
                             {vendor.riskScan?.sentiment === 'Negative' ? (
                                 <div className="bg-red-50 border border-red-100 p-2 rounded text-xs text-red-800 flex items-start gap-2">
                                     <AlertTriangle className="w-4 h-4 shrink-0" />
                                     <div>
                                         <p className="font-bold">Negative Sentiment Detected</p>
                                         <ul className="list-disc pl-3 mt-1 space-y-0.5">
                                             {vendor.riskScan.findings.map((f, i) => <li key={i}>{f}</li>)}
                                         </ul>
                                     </div>
                                 </div>
                             ) : (
                                 <div className="flex items-center gap-2 text-sm text-green-700">
                                     <CheckCircle className="w-4 h-4" /> No adverse media or risk indicators found.
                                 </div>
                             )}
                         </div>
                     </div>
                </div>

                {/* Document Center */}
                <div className="border-t border-slate-100">
                    <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                        <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Document Center</h4>
                        <button className="text-xs font-medium text-indigo-600 hover:text-indigo-800">+ Request Document</button>
                    </div>
                    {vendor.documents && vendor.documents.length > 0 ? (
                        <div className="divide-y divide-slate-100">
                            {vendor.documents.map(doc => (
                                <div key={doc.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                                    <div className="flex items-center gap-3">
                                        <FileText className="w-5 h-5 text-slate-400" />
                                        <div>
                                            <p className="text-sm font-medium text-slate-900">{doc.type}</p>
                                            <p className="text-xs text-slate-500">{doc.name} {doc.expiryDate && `• Expires: ${doc.expiryDate}`}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        {doc.status === 'Verified' ? (
                                            <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">Verified</span>
                                        ) : doc.status === 'Expired' ? (
                                            <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-medium">Expired</span>
                                        ) : (
                                            <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium">{doc.status}</span>
                                        )}
                                        <button className="text-slate-400 hover:text-indigo-600">
                                            <Download className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="p-6 text-center text-sm text-slate-500">No documents uploaded.</div>
                    )}
                </div>
            </div>

             {/* Contracts */}
             <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="font-bold text-slate-800">Associated Contracts</h3>
                    <button 
                        onClick={() => alert("Opening contract upload wizard...")}
                        className="text-indigo-600 text-sm font-medium hover:underline"
                    >
                        Upload New
                    </button>
                </div>
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 font-medium">
                        <tr>
                            <th className="px-6 py-3">Contract Title</th>
                            <th className="px-6 py-3">Value</th>
                            <th className="px-6 py-3">Duration</th>
                            <th className="px-6 py-3">Related Request</th>
                            <th className="px-6 py-3">Status</th>
                            <th className="px-6 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {vendor.contracts.map(contract => {
                            const isEditing = editingId === contract.id;
                            const daysRemaining = getDaysRemaining(contract.endDate);
                            const isDueSoon = daysRemaining >= 0 && daysRemaining <= 30 && contract.status !== 'Expired';
                            
                            return (
                            <tr key={contract.id} className={isDueSoon ? 'bg-amber-50 hover:bg-amber-100 transition-colors' : 'hover:bg-slate-50 transition-colors'}>
                                <td className="px-6 py-4 font-medium text-slate-900">
                                    {isEditing ? (
                                        <input 
                                            type="text"
                                            value={editForm.title || ''}
                                            onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                                            className="w-full p-1 border rounded text-xs"
                                        />
                                    ) : (
                                        <div className="flex items-center gap-2">
                                            {contract.title}
                                            {isDueSoon && <AlertTriangle className="w-3 h-3 text-amber-600" />}
                                        </div>
                                    )}
                                </td>
                                <td className="px-6 py-4">
                                    {isEditing ? (
                                        <input 
                                            type="number"
                                            value={editForm.value || 0}
                                            onChange={(e) => setEditForm({...editForm, value: Number(e.target.value)})}
                                            className="w-24 p-1 border rounded text-xs"
                                        />
                                    ) : `$${contract.value.toLocaleString()}`}
                                </td>
                                <td className="px-6 py-4 text-slate-600">
                                    {isEditing ? (
                                        <div className="flex flex-col gap-1">
                                            <input 
                                                type="date"
                                                value={editForm.startDate || ''}
                                                onChange={(e) => setEditForm({...editForm, startDate: e.target.value})}
                                                className="p-1 border rounded text-xs"
                                            />
                                            <input 
                                                type="date"
                                                value={editForm.endDate || ''}
                                                onChange={(e) => setEditForm({...editForm, endDate: e.target.value})}
                                                className="p-1 border rounded text-xs"
                                            />
                                        </div>
                                    ) : (
                                        <div className="flex flex-col">
                                            <span>{contract.startDate} - {contract.endDate}</span>
                                            {isDueSoon && <span className="text-xs text-amber-700 font-medium">{daysRemaining} days left</span>}
                                        </div>
                                    )}
                                </td>
                                <td className="px-6 py-4">
                                  {(() => {
                                      const req = getRelatedRequest(contract.relatedRequestId);
                                      return req ? (
                                          <button 
                                              onClick={() => onSelectRequest(req)}
                                              className="flex items-center gap-1.5 text-indigo-600 hover:text-indigo-800 font-medium transition-colors group"
                                          >
                                              <FileText className="w-4 h-4" />
                                              <span className="group-hover:underline">{req.id}</span>
                                          </button>
                                      ) : (
                                          <span className="text-slate-400">-</span>
                                      );
                                  })()}
                                </td>
                                <td className="px-6 py-4">
                                    {isEditing ? (
                                        <select
                                            value={editForm.status || 'Active'}
                                            onChange={(e) => setEditForm({...editForm, status: e.target.value as any})}
                                            className="p-1 border rounded text-xs"
                                        >
                                            <option value="Active">Active</option>
                                            <option value="Expired">Expired</option>
                                            <option value="Renewal Due">Renewal Due</option>
                                        </select>
                                    ) : (
                                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                                            isDueSoon ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                                            contract.status === 'Active' ? 'bg-green-100 text-green-800' : 
                                            contract.status === 'Expired' ? 'bg-slate-100 text-slate-600' : 'bg-amber-100 text-amber-800'
                                        }`}>
                                            {isDueSoon ? 'Renewal Due' : contract.status}
                                        </span>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-right">
                                    {isEditing ? (
                                        <div className="flex items-center justify-end gap-2">
                                            <button onClick={saveEdit} className="text-green-600 hover:text-green-800">
                                                <Save className="w-4 h-4" />
                                            </button>
                                            <button onClick={cancelEdit} className="text-red-600 hover:text-red-800">
                                                <X className="w-4 h-4" />
                                            </button>
                                        </div>
                                    ) : (
                                        <div className="flex items-center justify-end gap-2">
                                            <button onClick={() => startEdit(contract)} className="text-slate-400 hover:text-indigo-600">
                                                <Edit2 className="w-4 h-4" />
                                            </button>
                                            <button 
                                                onClick={() => window.open('https://example.com/contract.pdf', '_blank')}
                                                className="text-slate-400 hover:text-indigo-600"
                                            >
                                                <ExternalLink className="w-4 h-4" />
                                            </button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        )})}
                    </tbody>
                </table>
             </div>
        </div>

        {/* Right Column: Performance & Trust */}
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-slate-800 mb-4">Performance Scorecard</h3>
                
                <div className="flex items-center justify-center py-6 relative border-b border-slate-100 mb-6">
                    <div className="text-center">
                        <div className="text-5xl font-bold text-indigo-600">{vendor.trustScore}</div>
                        <div className="text-sm text-slate-500 mt-1">Overall Trust Score</div>
                    </div>
                </div>

                {/* Trust Score Breakdown */}
                <div className="mb-8">
                    <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-4">Trust Factors</h4>
                    <div className="space-y-5">
                        {trustFactors.map((factor) => (
                            <div key={factor.label}>
                                <div className="flex justify-between text-sm mb-1.5">
                                    <div className="flex items-center gap-2">
                                        <factor.icon className={`w-4 h-4 ${factor.color}`} />
                                        <span className="text-slate-700 font-medium">{factor.label}</span>
                                    </div>
                                    <span className="font-bold text-slate-900">{factor.score}/100</span>
                                </div>
                                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                                    <div 
                                        className={`h-full ${factor.barColor} transition-all duration-1000 ease-out`} 
                                        style={{ width: `${factor.score}%` }}
                                    ></div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Operational Performance */}
                <div>
                    <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-4">Operational Metrics</h4>
                    <div className="space-y-4">
                        <div>
                            <div className="flex justify-between text-sm mb-1">
                                <span className="text-slate-600">Quality of Service</span>
                                <span className="font-medium text-slate-900">4.8/5.0</span>
                            </div>
                            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                <div className="h-full bg-slate-800 w-[96%]"></div>
                            </div>
                        </div>
                        <div>
                            <div className="flex justify-between text-sm mb-1">
                                <span className="text-slate-600">Support Responsiveness</span>
                                <span className="font-medium text-slate-900">3.9/5.0</span>
                            </div>
                            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                <div className="h-full bg-slate-800 w-[78%]"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-6 pt-6 border-t border-slate-100">
                    <h4 className="text-sm font-semibold text-slate-800 mb-3">Recent Incidents</h4>
                    <div className="flex items-start gap-3 text-sm text-slate-600">
                        <CheckCircle className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                        <span>No critical incidents reported in the last 6 months.</span>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};