
import React from 'react';
import { Vendor } from '../types';
import { ShieldCheck, Star, ChevronRight, Trash2 } from 'lucide-react';

interface VendorListProps {
  vendors: Vendor[];
  onSelect: (vendor: Vendor) => void;
  onAdd?: () => void;
  onDelete?: (id: string) => void;
}

export const VendorList: React.FC<VendorListProps> = ({ vendors, onSelect, onAdd, onDelete }) => {
  return (
    <div className="space-y-6">
        <div className="flex justify-between items-center">
            <div>
                <h2 className="text-2xl font-bold text-slate-800">Vendor Directory</h2>
                <p className="text-slate-500">Manage your approved suppliers and contracts.</p>
            </div>
            <button 
                onClick={onAdd}
                className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 shadow-sm flex items-center gap-2"
            >
                + Add Vendor
            </button>
        </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50 text-slate-500 font-medium">
              <tr>
                <th className="px-6 py-3">Vendor Name</th>
                <th className="px-6 py-3">Category</th>
                <th className="px-6 py-3">Trust Score</th>
                <th className="px-6 py-3">Performance</th>
                <th className="px-6 py-3">Spend (YTD)</th>
                <th className="px-6 py-3">Status</th>
                <th className="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {vendors.map((vendor) => (
                <tr 
                    key={vendor.id} 
                    className="hover:bg-slate-50 transition-colors group"
                >
                  <td className="px-6 py-4 cursor-pointer" onClick={() => onSelect(vendor)}>
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs border border-indigo-100">
                            {vendor.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                            <div className="font-medium text-slate-900">{vendor.name}</div>
                            {vendor.isPreferred && (
                                <span className="text-[10px] px-1.5 py-0.5 bg-green-100 text-green-700 rounded-full font-medium border border-green-200">Preferred</span>
                            )}
                        </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-600 cursor-pointer" onClick={() => onSelect(vendor)}>{vendor.category}</td>
                  <td className="px-6 py-4 cursor-pointer" onClick={() => onSelect(vendor)}>
                    <div className="flex items-center gap-1.5">
                        <ShieldCheck className={`w-4 h-4 ${vendor.trustScore > 80 ? 'text-green-500' : 'text-amber-500'}`} />
                        <span className="font-medium text-slate-700">{vendor.trustScore}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 cursor-pointer" onClick={() => onSelect(vendor)}>
                     <div className="flex items-center">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                        <span className="ml-1.5 font-medium text-slate-700">{vendor.performanceRating}/5</span>
                     </div>
                  </td>
                  <td className="px-6 py-4 font-mono text-slate-600 cursor-pointer" onClick={() => onSelect(vendor)}>${vendor.spendLast12M.toLocaleString()}</td>
                  <td className="px-6 py-4 cursor-pointer" onClick={() => onSelect(vendor)}>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        vendor.onboardingStatus === 'Complete' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                        {vendor.onboardingStatus}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                        <button 
                            onClick={(e) => { e.stopPropagation(); onDelete?.(vendor.id); }}
                            className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                            title="Delete Vendor"
                        >
                            <Trash2 className="w-4 h-4" />
                        </button>
                        <button 
                            onClick={() => onSelect(vendor)}
                            className="p-2 text-slate-300 hover:text-indigo-600 rounded-full transition-colors"
                        >
                             <ChevronRight className="w-5 h-5" />
                        </button>
                    </div>
                  </td>
                </tr>
              ))}
              {vendors.length === 0 && (
                  <tr>
                      <td colSpan={7} className="text-center py-12 text-slate-500">
                          No vendors found. Add one to get started.
                      </td>
                  </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
