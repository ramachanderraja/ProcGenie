
import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysis, BuyingChannel, ProcurementRequest, ContractAnalysis, ContractExtractionResponse } from "../types";

// Helper to get fresh instance
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    riskScore: { type: Type.NUMBER },
    riskFactors: { type: Type.ARRAY, items: { type: Type.STRING } },
    summary: { type: Type.STRING },
    recommendedCategory: { type: Type.STRING },
    policyCheck: { type: Type.BOOLEAN },
    complianceNotes: { type: Type.STRING },
    suggestedChannel: { type: Type.STRING, enum: ["Catalog", "Contract", "Quick Quote", "Statement of Work"] },
    impactedDocuments: { type: Type.ARRAY, items: { type: Type.STRING } }
  },
  required: ["riskScore", "riskFactors", "summary", "recommendedCategory", "policyCheck", "complianceNotes", "suggestedChannel", "impactedDocuments"]
};

export const GeminiService = {
  async analyzeIntakePrompt(prompt: string): Promise<Partial<ProcurementRequest> & { aiAnalysis: AIAnalysis }> {
    const ai = getAI();
    const systemInstruction = `
      You are a Procurement Concierge. Analyze the user's buying request.
      1. Identify the item/service.
      2. Determine the Buying Channel: 
         - 'Catalog' for common hardware/supplies.
         - 'Contract' for renewals or existing services.
         - 'Quick Quote' for new items not in catalog.
         - 'Statement of Work' for complex services.
      3. Identify impacted documents (e.g. "MSA", "SOW", "New Vendor Form").
      4. Check policy: Software needs Security review. >$10k needs VP approval.
    `;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              amount: { type: Type.NUMBER },
              vendorName: { type: Type.STRING },
              category: { type: Type.STRING },
              aiAnalysis: analysisSchema
            }
          }
        }
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("Gemini Analysis Error:", error);
      throw error;
    }
  },

  async chat(history: any[], message: string) {
    const ai = getAI();
    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: "You are a Procurement Policy Assistant. Help users navigate buying rules, vendor checks, and intake forms.",
      },
      history
    });
    const result = await chat.sendMessage({ message });
    return result.text;
  },

  async extractContractData(file: { data: string, mimeType: string }): Promise<ContractExtractionResponse> {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { inlineData: file },
          { text: "Extract metadata from this contract: title, vendorName, type, value, startDate, endDate, paymentTerms, autoRenewal (bool)." }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            vendorName: { type: Type.STRING },
            type: { type: Type.STRING },
            value: { type: Type.NUMBER },
            startDate: { type: Type.STRING },
            endDate: { type: Type.STRING },
            paymentTerms: { type: Type.STRING },
            autoRenewal: { type: Type.BOOLEAN }
          },
          required: ["title", "vendorName", "type", "value", "startDate", "endDate", "paymentTerms", "autoRenewal"]
        }
      }
    });
    return JSON.parse(response.text);
  },

  async analyzeContract(input: string | { data: string, mimeType: string }): Promise<ContractAnalysis> {
    const ai = getAI();
    const parts = typeof input === 'string' 
      ? [{ text: input }, { text: "Perform a deep risk analysis on this contract text." }]
      : [{ inlineData: input }, { text: "Perform a deep risk analysis on this contract document." }];

    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            keyTerms: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  term: { type: Type.STRING },
                  value: { type: Type.STRING },
                  riskLevel: { type: Type.STRING, enum: ["High", "Medium", "Low"] }
                },
                required: ["term", "value", "riskLevel"]
              }
            },
            indemnificationClause: { type: Type.STRING },
            confidentialityClause: { type: Type.STRING },
            governingLaw: { type: Type.STRING },
            terminationClause: { type: Type.STRING },
            renewalDate: { type: Type.STRING }
          },
          required: ["summary", "keyTerms"]
        }
      }
    });
    return JSON.parse(response.text);
  }
};
