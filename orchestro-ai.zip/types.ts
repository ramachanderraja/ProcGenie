
export enum RequestStatus {
  DRAFT = 'Draft',
  PENDING_APPROVAL = 'Pending Approval',
  APPROVED = 'Approved',
  REJECTED = 'Rejected',
  PROCUREMENT_REVIEW = 'Procurement Review',
  ORDER_PLACED = 'Order Placed',
  RECEIVED = 'Received'
}

export enum Priority {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High',
  URGENT = 'Urgent'
}

export enum BuyingChannel {
  CATALOG = 'Catalog',
  CONTRACT = 'Contract',
  QUICK_QUOTE = 'Quick Quote',
  SOW = 'Statement of Work'
}

export interface CatalogItem {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  vendorName: string;
  category: string;
  imageUrl: string;
  deliveryTime: string;
  accountingCode?: string;
}

export interface QuickQuote {
  id: string;
  requestId: string;
  suppliers: {
    name: string;
    price: number;
    deliveryDate: string;
    isApproved: boolean;
    rating: number;
  }[];
  selectedSupplier?: string;
}

export interface Comment {
  id: string;
  author: string;
  text: string;
  timestamp: string;
  role?: string;
}

export interface ApprovalStep {
  id: string;
  name: string;
  role: 'Manager' | 'Finance' | 'Legal' | 'IT' | 'Procurement' | 'VP' | 'Security';
  status: 'pending' | 'approved' | 'rejected' | 'skipped' | 'current';
  approverName?: string;
  timestamp?: string;
  comments?: string;
}

export interface AIAnalysis {
  riskScore: number;
  riskFactors: string[];
  summary: string;
  recommendedCategory: string;
  policyCheck: boolean;
  complianceNotes: string;
  suggestedChannel: BuyingChannel;
  impactedDocuments: string[];
}

export interface ProcurementRequest {
  id: string;
  title: string;
  requester: string;
  department: string;
  amount: number;
  currency: string;
  vendorName: string;
  isNewVendor?: boolean;
  category: string;
  description: string;
  businessJustification: string;
  status: RequestStatus;
  priority: Priority;
  createdAt: string;
  aiAnalysis?: AIAnalysis;
  attachments: string[];
  comments: Comment[];
  approvalSteps: ApprovalStep[];
  buyingChannel?: BuyingChannel;
  catalogItemId?: string;
  purchaseOrderNumber?: string;
  owner?: string;
}

export interface Vendor {
  id: string;
  name: string;
  category: string;
  trustScore: number;
  isPreferred: boolean;
  contactName: string;
  contactEmail: string;
  website: string;
  description: string;
  spendLast12M: number;
  performanceRating: number;
  onboardingStatus: 'Complete' | 'In Progress' | 'Pending';
  contracts: Contract[];
  complianceStatus?: {
    taxValid: string;
    bankValid: string;
    sanctionsCheck: string;
  };
  riskScan?: {
    lastScanned: string;
    sentiment: string;
    findings: string[];
  };
  onboardingSteps?: { name: string; status: string }[];
  documents?: { id: string; type: string; name: string; expiryDate?: string; status: string }[];
}

export interface Contract {
  id: string;
  title: string;
  vendorName: string;
  type: string;
  value: number;
  startDate: string;
  endDate: string;
  status: 'Active' | 'Renewal Due' | 'Expired' | 'Draft';
  paymentTerms: string;
  autoRenewal: boolean;
  owner: string;
  relatedRequestId?: string;
  aiAnalysis?: ContractAnalysis;
}

export interface ContractAnalysis {
  summary: string;
  keyTerms: { term: string; value: string; riskLevel: 'High' | 'Medium' | 'Low' }[];
  indemnificationClause?: string;
  confidentialityClause?: string;
  governingLaw?: string;
  terminationClause?: string;
  renewalDate?: string;
}

export interface ContractExtractionResponse {
  title: string;
  vendorName: string;
  type: string;
  value: number;
  startDate: string;
  endDate: string;
  paymentTerms: string;
  autoRenewal: boolean;
}

export interface PurchaseOrder {
  poNumber: string;
  requestId: string;
  vendorName: string;
  amount: number;
  currency: string;
  status: 'Sent' | 'Acknowledged' | 'Fulfilled' | 'Invoiced' | 'Paid';
  createdAt: string;
  description: string;
}

export interface SourcingProject {
  id: string;
  title: string;
  status: 'Draft' | 'Active' | 'Selection' | 'Closed';
  owner: string;
  budget: number;
  dueDate: string;
  vendors: string[];
  type: 'RFP' | 'RFI' | 'Renewal';
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  vendorName: string;
  amount: number;
  date: string;
  status: string;
  matchStatus: string;
  poNumber?: string;
}

export interface Integration {
  id: string;
  name: string;
  type: string;
  status: 'Connected' | 'Disconnected' | 'Syncing';
  lastSync?: string;
}
